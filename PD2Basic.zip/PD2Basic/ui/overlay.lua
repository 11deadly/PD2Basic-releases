PD2Basic.Overlay = PD2Basic.Overlay or {}
local O = PD2Basic.Overlay
local W = PD2Basic.Widgets

local MOUSE_ID = "pd2basic_overlay"
local WIN_W, WIN_H = 1080, 640
local PAD = 16
local COL_GAP = 14
local HEADER_H = 60
local NAV_Y, NAV_H = 68, 36
local BODY_Y = 114
local DESC_H = 40
local PRESET_H = 42

local WHEEL_UP = Idstring("mouse wheel up")
local WHEEL_DOWN = Idstring("mouse wheel down")

O._last_screen = O._last_screen or {}
O._spawn_mode = O._spawn_mode or 1

function O.is_open()
	return O._root ~= nil
end

function O.is_typing()
	return O._focused ~= nil
end

local function context()
	return Utils:IsInGameState() and "game" or "menu"
end

local function current_state_name()
	return game_state_machine and game_state_machine:current_state_name() or "none"
end

local function in_game()
	return Utils:IsInGameState() and managers.player and alive(managers.player:player_unit())
end

local function status_pill()
	if not Utils:IsInGameState() then
		return W.loc("pd2basic_status_pill_menu"), W.COLORS.dim
	end
	local allowed, reason = PD2Basic.is_allowed()
	local text = PD2Basic.reason_text(reason):upper()
	if not allowed then
		return W.loc("pd2basic_status_blocked"):upper() .. ": " .. text, W.COLORS.accent
	end
	if reason:find("client", 1, true) then
		return text, W.COLORS.warning
	end
	return text, W.COLORS.on
end

function O.show_message(msg)
	if O._desc and alive(O._desc) then
		O._desc:set_text(tostring(msg))
		O._desc:set_color(W.COLORS.text)
	end
end

function O._unfocus()
	if not O._focused then
		return
	end
	O._focused.set_focus(false)
	O._focused = nil
	if O._root and alive(O._root) then
		O._root:enter_text(nil)
		O._root:key_press(nil)
	end
	managers.mouse_pointer:workspace():disconnect_keyboard()
end

function O._focus(widget)
	if O._focused == widget then
		return
	end
	O._unfocus()
	O._focused = widget
	widget.set_focus(true)
	managers.mouse_pointer:workspace():connect_keyboard(Input:keyboard())
	O._root:enter_text(function(o, s)
		PD2Basic.safe_call("overlay enter_text", function()
			if O._focused then
				O._focused.enter_text(s)
			end
		end)
	end)
	O._root:key_press(function(o, k)
		PD2Basic.safe_call("overlay key_press", function()
			if O._focused and O._focused.key_press(k) then
				O._unfocus()
			end
		end)
	end)
end

function O._close_dropdown()
	if O._dropdown and alive(O._dropdown.panel) then
		O._root:remove(O._dropdown.panel)
	end
	O._dropdown = nil
end

function O._open_dropdown(row)
	O._close_dropdown()
	local options = row.options()
	local item_h = 26
	local w = math.max(180, row.panel:w() * 0.5)
	local x = row.panel:world_x() - O._root:world_x() + row.panel:w() - w
	local y = row.panel:world_y() - O._root:world_y() + row.panel:h()
	local h = #options * item_h + 4
	if y + h > WIN_H - 8 then
		y = row.panel:world_y() - O._root:world_y() - h
	end
	local panel = O._root:panel({ x = x, y = y, w = w, h = h, layer = 20 })
	panel:rect({ color = Color(1, 0.06, 0.065, 0.085), layer = 0 })
	panel:rect({ h = 2, color = row.color, layer = 1 })
	local dropdown = { panel = panel, buttons = {} }
	for i, option in ipairs(options) do
		local button = W.button(panel, 2, 2 + (i - 1) * item_h, w - 4, item_h, option.label, function()
			O._close_dropdown()
			row.select(i)
		end, "", {
			bg = option.selected and row.color:with_alpha(0.2) or W.COLORS.row,
			hover = row.color:with_alpha(0.35),
			color = option.selected and row.color or W.COLORS.text,
		})
		button.text:set_align("left")
		button.text:set_x(12)
		table.insert(dropdown.buttons, button)
	end
	O._dropdown = dropdown
end

local function clear_body()
	O._unfocus()
	O._close_dropdown()
	if O._body and alive(O._body) then
		O._root:remove(O._body)
	end
	local footer = O._context == "game" and (DESC_H + PRESET_H) or DESC_H
	O._body = O._root:panel({ x = PAD, y = BODY_Y, w = WIN_W - PAD * 2, h = WIN_H - BODY_Y - footer - 6 })
	O._widgets = {}
end

local function build_columns(columns)
	local col_w = math.floor((O._body:w() - COL_GAP * 2) / 3)
	for c, column in ipairs(columns) do
		local x = (c - 1) * (col_w + COL_GAP)
		local y = 0
		for _, group in ipairs(column) do
			if #W.visible_items(group) > 0 then
				y = y + W.group(O._body, x, y, col_w, group, O._widgets) + 10
			end
		end
	end
end

local function build_spawn()
	local w = O._body:w()
	local color = W.GROUP_COLORS.spawn
	local mode_w = math.floor((w - COL_GAP) / 2)
	for i, mode in ipairs(PD2Basic.SPAWN_MODES) do
		local active = i == O._spawn_mode
		table.insert(O._widgets, W.button(O._body, (i - 1) * (mode_w + COL_GAP), 0, mode_w, 30, W.loc("pd2basic_" .. mode.id .. "_title"):upper(), function()
			O._spawn_mode = i
			O.refresh_page()
		end, W.loc("pd2basic_" .. mode.id .. "_desc"), {
			bg = active and color:with_alpha(0.22) or W.COLORS.card,
			hover = color:with_alpha(0.32),
			color = active and color or W.COLORS.dim,
			font = W.font_bold(),
		}))
	end
	local mode = PD2Basic.SPAWN_MODES[O._spawn_mode]
	local y = 40
	table.insert(O._widgets, W.search(O._body, y, w, mode.search, color))
	y = y + W.ROW_H + 6
	local list = W.list(O._body, y, w, mode.list, color)
	table.insert(O._widgets, list)
	y = y + list.height + 8
	local count = #mode.buttons
	local button_w = math.floor((w - COL_GAP * (count - 1)) / count)
	for i, def in ipairs(mode.buttons) do
		local holder = O._body:panel({ x = (i - 1) * (button_w + COL_GAP), y = y, w = button_w, h = W.ROW_H })
		holder:rect({ color = color:with_alpha(0.12), layer = 0 })
		table.insert(O._widgets, W.action(holder, 0, button_w, def, color))
	end
end

local function build_config()
	local general = { id = "general", items = {
		{ kind = "toggle", id = "master_enabled" },
		{ kind = "toggle", id = "reset_each_heist" },
	} }
	local language = { id = "language", items = { { kind = "language", id = "language" } } }
	local hotkeys = { id = "hotkeys", columns = 2, items = {} }
	for _, def in ipairs(PD2Basic.Hotkeys.ACTIONS) do
		table.insert(hotkeys.items, { kind = "hotkey", id = def.id })
	end
	build_columns({ { language, general } })
	local col_w = math.floor((O._body:w() - COL_GAP * 2) / 3)
	W.group(O._body, col_w + COL_GAP, 0, col_w * 2 + COL_GAP, hotkeys, O._widgets)
end

local function build_screen()
	clear_body()
	local screen = PD2Basic.screen_by_id(O._screen)
	if screen.spawn then
		build_spawn()
	elseif screen.config then
		build_config()
	else
		build_columns(screen.columns)
	end
end

local function build_preset_bar()
	if O._preset_bar and alive(O._preset_bar) then
		O._root:remove(O._preset_bar)
	end
	O._preset_widgets = {}
	if O._context ~= "game" then
		return
	end
	local bar = O._root:panel({ x = PAD, y = WIN_H - DESC_H - PRESET_H, w = WIN_W - PAD * 2, h = PRESET_H - 6 })
	O._preset_bar = bar
	bar:rect({ color = W.COLORS.card, layer = 0 })
	local color = W.GROUP_COLORS.presets

	local label = W.text(bar, { text = W.loc("pd2basic_presets_label"), font = W.font_bold(), font_size = W.font_size() * 0.9, color = color, x = 10 })
	local _, _, label_w = label:text_rect()
	local x = 20 + label_w

	local holder = bar:panel({ x = x, y = 4, w = 240, h = W.ROW_H })
	table.insert(O._preset_widgets, W.search(holder, 0, 240, { id = "preset_name" }, color))
	x = x + 246

	table.insert(O._preset_widgets, W.button(bar, x, 5, 120, PRESET_H - 16, W.loc("pd2basic_preset_save_button"), function()
		PD2Basic.actions.save_preset()
	end, W.loc("pd2basic_save_preset_desc"), { bg = color:with_alpha(0.2), hover = color:with_alpha(0.4), color = color }))
	x = x + 130

	local presets = PD2Basic.sources.presets()
	local shown = 0
	for i, preset in ipairs(presets) do
		local chip_text = tostring(i) .. "  " .. preset.id
		local chip_w = 26 + #chip_text * 9
		if x + chip_w > bar:w() - 50 then
			break
		end
		local name = preset.id
		local hint = W.loc("pd2basic_preset_chip_hint"):gsub("%$N", tostring(i))
		table.insert(O._preset_widgets, W.button(bar, x, 5, chip_w, PRESET_H - 16, chip_text, function(_, button)
			PD2Basic.inputs.preset_list = name
			if button == W.RIGHT_BUTTON then
				if O._pending_delete == name then
					O._pending_delete = nil
					PD2Basic.actions.delete_preset()
				else
					O._pending_delete = name
					PD2Basic.say("preset_delete_confirm", name)
				end
				return
			end
			O._pending_delete = nil
			PD2Basic.actions.load_preset()
		end, preset.label .. ".  " .. hint, { bg = W.COLORS.field, hover = color:with_alpha(0.3) }))
		x = x + chip_w + 6
		shown = shown + 1
	end
	if shown < #presets then
		W.text(bar, { text = "+" .. (#presets - shown), color = W.COLORS.dim, x = x + 4 })
	end
end

local function build_nav()
	if O._nav and alive(O._nav) then
		O._root:remove(O._nav)
	end
	O._nav_widgets = {}
	local screens = PD2Basic.SCREENS
	local nav = O._root:panel({ x = PAD, y = NAV_Y, w = WIN_W - PAD * 2, h = NAV_H })
	O._nav = nav
	local button_w = math.floor((nav:w() - 6 * (#screens - 1)) / #screens)
	for i, screen in ipairs(screens) do
		local active = screen.id == O._screen
		local available = PD2Basic.screen_available(screen, O._context)
		local key = PD2Basic.Hotkeys.key_label("screen_" .. screen.id)
		local label = W.loc("pd2basic_screen_" .. screen.id):upper()
		local x = (i - 1) * (button_w + 6)
		local desc = W.loc("pd2basic_screen_" .. screen.id .. "_desc")
		if not available then
			desc = W.loc("pd2basic_screen_unavailable_" .. screen.context) .. "  " .. desc
		end
		local button = W.button(nav, x, 0, button_w, NAV_H, label, function()
			if not available then
				PD2Basic.notify(W.loc("pd2basic_screen_unavailable_" .. screen.context))
				return
			end
			O._screen = screen.id
			O._last_screen[O._context] = screen.id
			O.refresh_page()
		end, desc, {
			bg = active and W.COLORS.accent:with_alpha(0.16) or W.COLORS.card,
			hover = available and W.COLORS.accent:with_alpha(0.26) or W.COLORS.card,
			color = active and W.COLORS.text or (available and W.COLORS.dim or W.COLORS.line),
			font = W.font_bold(),
			font_size = W.font_size() * 0.85,
		})

		if key ~= "-" then
			W.text(button.panel, { text = key, x = 4, y = 1, w = button_w - 8, h = 12, align = "right", vertical = "top", color = W.COLORS.dim, font_size = W.font_size() * 0.55 })
		end
		if active then
			nav:rect({ x = x, y = NAV_H - 3, w = button_w, h = 3, color = W.COLORS.accent, layer = 3 })
		end
		table.insert(O._nav_widgets, button)
	end
end

function O.refresh_page()
	if not O.is_open() then
		return
	end
	build_nav()
	build_screen()
	build_preset_bar()
end

function O.on_input_changed(input_id)
	for _, widget in ipairs(O._widgets or {}) do
		if widget.search_id == input_id and widget.refilter then
			widget.refilter()
		end
	end
end

local function build_header(root)
	local title_size = 34
	local small_size = W.font_size() * 0.8
	local x = PAD
	for _, part in ipairs({
		{ text = "PD2", color = Color(0.902, 0.224, 0.196), size = title_size, font = W.font_bold() },
		{ text = "Basic", color = Color(0.941, 0.941, 0.941), size = title_size, font = W.font_bold() },
		{ text = "by deadly", color = Color(0.627, 0.627, 0.647), size = small_size, gap = 10, lift = (title_size - small_size) * 0.2 },
	}) do
		x = x + (part.gap or 0)
		local label = W.text(root, {
			text = part.text,
			font = part.font,
			font_size = part.size,
			color = part.color,
			x = x,
			y = 6 - (part.lift or 0),
			h = 44,
			vertical = "bottom",
		})
		local _, _, w = label:text_rect()
		x = x + w
	end

	local status, status_color = status_pill()
	table.insert(O._fixed_widgets, W.button(root, WIN_W - 500, 15, 230, 28, status, function() end, W.loc("pd2basic_status_desc"), {
		bg = status_color:with_alpha(0.15),
		hover = status_color:with_alpha(0.25),
		color = status_color,
		font_size = W.font_size() * 0.75,
	}))

	local master
	local function master_look()
		local on = PD2Basic.settings.master_enabled
		local color = on and W.COLORS.on or W.COLORS.accent
		master.text:set_text(on and "MASTER ON" or "MASTER OFF")
		master.set_colors(color:with_alpha(0.18), color)
	end
	master = W.button(root, WIN_W - 262, 15, 170, 28, "", function()
		PD2Basic.set_setting("master_enabled", not PD2Basic.settings.master_enabled)
		master_look()
	end, W.loc("pd2basic_master_enabled_desc"), { font = W.font_bold(), font_size = W.font_size() * 0.8 })
	master_look()
	table.insert(O._fixed_widgets, master)

	table.insert(O._fixed_widgets, W.button(root, WIN_W - PAD - 70, 15, 70, 28, W.loc("pd2basic_close_button"), function()
		O.close()
	end, W.loc("pd2basic_close_desc"), { bg = W.COLORS.card, hover = W.COLORS.accent:with_alpha(0.45), font_size = W.font_size() * 0.8 }))

	root:rect({ y = HEADER_H, h = 1, color = W.COLORS.line, layer = 1 })
end

function O._build()
	local full = managers.mouse_pointer:workspace():panel()

	local root = full:panel({ w = WIN_W, h = WIN_H, layer = tweak_data.gui.MOUSE_LAYER - 200 })
	root:set_center(full:w() / 2, full:h() / 2)
	O._root = root
	O._context = context()
	O._fixed_widgets = {}

	local screen = PD2Basic.screen_by_id(O._screen or "")
	if not screen or not PD2Basic.screen_available(screen, O._context) then
		local last = PD2Basic.screen_by_id(O._last_screen[O._context] or "")
		O._screen = last and PD2Basic.screen_available(last, O._context) and last.id or PD2Basic.first_screen_for(O._context).id
	end
	O._last_screen[O._context] = O._screen

	root:rect({ color = W.COLORS.bg, layer = -1 })
	root:rect({ h = 3, color = W.COLORS.accent, layer = 0 })
	root:rect({ y = 3, h = HEADER_H - 3, color = W.COLORS.accent:with_alpha(0.05), layer = 0 })
	root:rect({ w = 1, color = W.COLORS.line, layer = 0 })
	root:rect({ x = WIN_W - 1, w = 1, color = W.COLORS.line, layer = 0 })
	root:rect({ y = WIN_H - 1, h = 1, color = W.COLORS.line, layer = 0 })

	build_header(root)

	root:rect({ y = WIN_H - DESC_H, h = 1, color = W.COLORS.line, layer = 0 })
	O._desc = W.text(root, {
		text = W.loc(O._context == "game" and "pd2basic_footer_game" or "pd2basic_footer_menu"),
		color = W.COLORS.dim,
		font_size = W.font_size() * 0.75,
		x = PAD,
		y = WIN_H - DESC_H + 2,
		w = WIN_W - PAD * 2,
		h = DESC_H - 4,
		wrap = true,
		word_wrap = true,
	})

	O.refresh_page()
end

function O._widget_at(x, y)
	if O._dropdown then
		for _, button in ipairs(O._dropdown.buttons) do
			if alive(button.panel) and button.panel:inside(x, y) then
				return button
			end
		end
	end
	for _, list in ipairs({ O._fixed_widgets, O._nav_widgets, O._preset_widgets, O._widgets }) do
		for _, w in ipairs(list or {}) do
			if alive(w.panel) and w.panel:inside(x, y) then
				return w
			end
		end
	end
	return nil
end

function O._mouse_move(o, x, y)
	PD2Basic.safe_call("overlay mouse_move", function()
		if O._dragging then
			O._dragging.drag(x, y)
			return
		end
		local hovered = O._widget_at(x, y)
		if hovered ~= O._hovered then
			if O._hovered and alive(O._hovered.panel) then
				O._hovered.set_hover(false)
			end
			O._hovered = hovered
			if hovered then
				hovered.set_hover(true)
				if hovered.desc and hovered.desc ~= "" then
					O._desc:set_text(hovered.desc)
					O._desc:set_color(W.COLORS.dim)
				end
			end
		end
		managers.mouse_pointer:set_pointer_image(hovered and hovered.press and "link" or "arrow")
	end)
end

function O._mouse_press(o, button, x, y)
	PD2Basic.safe_call("overlay mouse_press", function()
		if button == WHEEL_UP or button == WHEEL_DOWN then
			local widget = O._widget_at(x, y)
			if widget and widget.scroll then
				widget.scroll(button == WHEEL_UP and -1 or 1)
			end
			return
		end
		if button ~= W.LEFT_BUTTON and button ~= W.RIGHT_BUTTON then
			return
		end
		local widget = O._widget_at(x, y)

		local in_dropdown = O._dropdown and O._dropdown.panel:inside(x, y)
		if O._dropdown and not in_dropdown then
			O._close_dropdown()
		end
		if O._focused and widget ~= O._focused then
			O._unfocus()
		end
		if widget and widget.press then
			local result = widget.press(x, y, button)
			if result == "focus" then
				O._focus(widget)
			elseif result == "dropdown" then
				O._open_dropdown(widget)
			elseif result and widget.drag then
				O._dragging = widget
			end
		end
		if not O.is_open() then
			return
		end

		local desc_text = O._desc:text()
		local desc_color = O._desc:color()
		O._hovered = nil
		O._mouse_move(o, x, y)
		O._desc:set_text(desc_text)
		O._desc:set_color(desc_color)
	end)
end

function O._mouse_release(o, button, x, y)
	PD2Basic.safe_call("overlay mouse_release", function()
		if O._dragging then
			O._dragging.release()
			O._dragging = nil
		end
	end)
end

function O.open()
	if O.is_open() then
		return
	end
	if not managers.mouse_pointer or not managers.gui_data then
		return
	end

	if Utils:IsInGameState() then
		if managers.menu and managers.menu:is_open("menu_pause") then
			return
		end
		if managers.hud and managers.hud._chat_focus then
			return
		end
	end

	O._build()
	O._opened_state = current_state_name()
	managers.mouse_pointer:use_mouse({
		id = MOUSE_ID,
		mouse_move = O._mouse_move,
		mouse_press = O._mouse_press,
		mouse_release = O._mouse_release,
	})
	managers.mouse_pointer:set_pointer_image("arrow")

	O._controller_disabled = false
	if in_game() then
		game_state_machine:current_state():set_controller_enabled(false)
		O._controller_disabled = true
	end
	PD2Basic.log("overlay opened (" .. tostring(O._context) .. ", " .. tostring(O._screen) .. ")")
end

function O.close()
	if not O.is_open() then
		return
	end
	O._unfocus()
	O._close_dropdown()
	if O._dragging then
		O._dragging.release()
		O._dragging = nil
	end
	O._hovered = nil
	O._pending_delete = nil

	if alive(O._root) then
		O._root:parent():remove(O._root)
	end
	O._root = nil
	O._desc = nil
	O._body = nil
	O._nav = nil
	O._preset_bar = nil
	managers.mouse_pointer:remove_mouse(MOUSE_ID)

	if O._controller_disabled and in_game() and not (managers.menu and managers.menu:is_open("menu_pause")) then
		game_state_machine:current_state():set_controller_enabled(true)
	end
	O._controller_disabled = false
	PD2Basic.log("overlay closed")
end

function O.toggle()
	if O.is_open() then
		O.close()
	else
		O.open()
	end
end

function O.toggle_screen(screen_id)
	local screen = PD2Basic.screen_by_id(screen_id)
	if not screen or not PD2Basic.screen_available(screen, context()) then
		return
	end
	if O.is_open() then
		if O._screen == screen_id then
			O.close()
		else
			O._screen = screen_id
			O._last_screen[O._context] = screen_id
			O.refresh_page()
		end
		return
	end
	O._screen = screen_id
	O._last_screen[context()] = screen_id
	O.open()
end

function O.update()
	if not O.is_open() then
		return
	end
	if current_state_name() ~= O._opened_state or not alive(O._root) then
		O.close()
		return
	end

	if Utils:IsInGameState() and managers.menu and managers.menu:is_open("menu_pause") then
		O.close()
	end
end

Hooks:Add("GameSetupUpdate", "PD2Basic_OverlayUpdateGame", function()
	PD2Basic.safe_call("overlay update", O.update)
end)

Hooks:Add("MenuUpdate", "PD2Basic_OverlayUpdateMenu", function()
	PD2Basic.safe_call("overlay update", O.update)
end)
