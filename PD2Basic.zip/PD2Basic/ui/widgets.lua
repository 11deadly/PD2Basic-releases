PD2Basic.Widgets = {}
local W = PD2Basic.Widgets

W.ROW_H = 28
W.COLORS = {
	bg = Color(0.93, 0.035, 0.04, 0.055),
	card = Color(0.75, 0.075, 0.08, 0.105),
	field = Color(1, 0.13, 0.135, 0.17),
	row = Color(0, 1, 1, 1),
	row_hover = Color(0.08, 1, 1, 1),
	text = Color(1, 0.92, 0.92, 0.94),
	dim = Color(1, 0.5, 0.52, 0.58),
	on = Color(1, 0.35, 0.9, 0.45),
	off = Color(1, 0.5, 0.52, 0.58),
	accent = Color(1, 0.95, 0.22, 0.2),
	warning = Color(1, 1, 0.6, 0.1),
	line = Color(1, 0.3, 0.31, 0.36),
}

W.GROUP_COLORS = {
	player = Color(1, 0.3, 0.85, 0.5),
	movement = Color(1, 0.3, 0.8, 0.85),
	interaction = Color(1, 0.55, 0.75, 1),
	weapons = Color(1, 0.95, 0.35, 0.3),
	consumables = Color(1, 1, 0.75, 0.2),
	bags = Color(1, 1, 0.55, 0.25),
	stealth = Color(1, 0.3, 0.6, 1),
	pagers = Color(1, 0.45, 0.7, 1),
	esp = Color(1, 0.75, 0.45, 1),
	timers = Color(1, 0.1, 0.9, 0.9),
	hostages = Color(1, 0.4, 0.85, 0.75),
	world = Color(1, 1, 0.45, 0.75),
	loot = Color(1, 1, 0.8, 0.3),
	heist = Color(1, 0.95, 0.3, 0.45),
	money = Color(1, 1, 0.75, 0.2),
	heist_rewards = Color(1, 1, 0.45, 0.75),
	level = Color(1, 0.3, 0.85, 0.5),
	points = Color(1, 0.3, 0.6, 1),
	shop = Color(1, 0.35, 0.9, 0.6),
	inventory = Color(1, 0.75, 0.45, 1),
	language = Color(1, 0.3, 0.8, 0.85),
	general = Color(1, 0.95, 0.35, 0.3),
	hotkeys = Color(1, 0.75, 0.45, 1),
	spawn = Color(1, 1, 0.75, 0.2),
	presets = Color(1, 0.5, 0.9, 0.9),
	melee = Color(1, 1, 0.5, 0.35),
	sentries = Color(1, 0.6, 0.8, 0.4),
	ai = Color(1, 0.85, 0.35, 0.35),
	map = Color(1, 0.4, 0.75, 0.95),
}

function W.visible_items(group)
	local in_game = Utils:IsInGameState()
	local list = {}
	for _, def in ipairs(group.items) do
		if not (def.menu_only and in_game) then
			table.insert(list, def)
		end
	end
	return list
end

W.LEFT_BUTTON = Idstring("0")
W.RIGHT_BUTTON = Idstring("1")

function W.font()
	return tweak_data.menu.pd2_medium_font
end

function W.font_bold()
	return tweak_data.menu.pd2_large_font
end

function W.font_size()
	return tweak_data.menu.pd2_small_font_size
end

function W.loc(key)
	return PD2Basic.text(key)
end

local function text(panel, params)
	params.font = params.font or W.font()
	params.font_size = params.font_size or W.font_size() * 0.85
	params.color = params.color or W.COLORS.text
	params.vertical = params.vertical or "center"
	params.layer = params.layer or 2
	return panel:text(params)
end
W.text = text

PD2Basic.risk_confirmed = PD2Basic.risk_confirmed or {}

function W.confirm_risk(def, run)
	local risk = PD2Basic.client_risk(def.id)
	if not risk then
		run()
		return
	end
	local warning = W.loc("pd2basic_limit_" .. risk)
	if PD2Basic.risk_confirmed[risk] then
		run()
		PD2Basic.notify(warning)
		return
	end

	local was_open = PD2Basic.Overlay.is_open()
	local function reopen()
		if was_open then
			PD2Basic.Overlay.open()
		end
	end
	PD2Basic.Overlay.close()
	QuickMenu:new(
		W.loc("pd2basic_risk_title"),
		warning .. "\n\n" .. W.loc("pd2basic_risk_question"),
		{
			{
				text = W.loc("pd2basic_risk_yes"),
				callback = function()
					PD2Basic.risk_confirmed[risk] = true
					PD2Basic.log("client risk accepted: " .. risk)
					PD2Basic.safe_call("risky cheat", run)
					reopen()
				end,
			},
			{ text = W.loc("pd2basic_risk_no"), is_cancel_button = true, callback = reopen },
		},
		true
	)
end

local function make_row(parent, y, w, def, color)
	local row = {}
	row.def = def
	row.color = color or W.COLORS.accent
	row.panel = parent:panel({ x = 0, y = y, w = w, h = W.ROW_H })
	row.hover_rect = row.panel:rect({ color = W.COLORS.row, layer = 0 })
	row.marker = row.panel:rect({ x = 0, y = 6, w = 2, h = W.ROW_H - 12, color = row.color:with_alpha(0), layer = 1 })
	row.title_string = W.loc("pd2basic_" .. def.id .. "_title")
	row.title = text(row.panel, { text = row.title_string, x = 10, w = w * 0.62 })
	row.desc = W.loc("pd2basic_" .. def.id .. "_desc")
	function row.set_hover(hover)
		row.hover_rect:set_color(hover and W.COLORS.row_hover or W.COLORS.row)
		row.marker:set_color(row.color:with_alpha(hover and 1 or 0))
	end
	return row
end

local function value_label(row, w)
	return text(row.panel, { text = "", x = w * 0.5, w = w * 0.5 - 12, align = "right" })
end

local function apply_client_limit(row, label, hide)
	local limit = PD2Basic.client_limit(row.def.id)
	if not limit then
		return
	end
	row.desc = W.loc("pd2basic_limit_" .. limit) .. "  " .. row.desc
	if limit == "host" then
		row.title:set_color(W.COLORS.dim)
		for _, obj in ipairs(hide or {}) do
			obj:set_visible(false)
		end
		function row.refresh()
			label:set_text(W.loc("pd2basic_limit_host_short"))
			label:set_color(W.COLORS.dim)
		end
		function row.press()
			PD2Basic.notify(W.loc("pd2basic_limit_host"))
		end
		row.refresh()
	else
		row.title:set_text(row.title_string .. "  (!)")
		row.title:set_color(W.COLORS.warning)
	end
end

function W.toggle(parent, y, w, def, color)
	local row = make_row(parent, y, w, def, color)
	local size = 14
	local box_x = w - size - 10
	local box_y = (W.ROW_H - size) / 2
	local border = row.panel:rect({ x = box_x, y = box_y, w = size, h = size, color = W.COLORS.line, layer = 1 })
	local inner = row.panel:rect({ x = box_x + 1, y = box_y + 1, w = size - 2, h = size - 2, color = W.COLORS.bg, layer = 2 })
	local fill = row.panel:rect({ x = box_x + 3, y = box_y + 3, w = size - 6, h = size - 6, color = row.color, layer = 3 })
	local label = text(row.panel, { text = "", x = w * 0.5, w = w * 0.5 - size - 18, align = "right", font_size = W.font_size() * 0.75 })

	function row.refresh()
		local on = PD2Basic.settings[def.id] and true or false
		fill:set_visible(on)
		border:set_color(on and row.color or W.COLORS.line)
		label:set_text(on and "ON" or "")
		label:set_color(row.color)
	end

	function row.press(x, y, button)
		local value = not PD2Basic.settings[def.id]
		local function apply()
			PD2Basic.set_setting(def.id, value)
			row.refresh()
		end
		if value then
			W.confirm_risk(def, apply)
		else
			apply()
		end
	end

	row.refresh()
	apply_client_limit(row, label, { border, inner, fill })
	return row
end

function W.choice(parent, y, w, def, color)
	local row = make_row(parent, y, w, def, color)
	local label = value_label(row, w - 14)
	local arrow = text(row.panel, { text = "v", x = w - 20, w = 12, align = "center", color = W.COLORS.dim, font_size = W.font_size() * 0.7 })
	row.desc = row.desc .. "  " .. W.loc("pd2basic_choice_hint")

	function row.refresh()
		local index = PD2Basic.settings[def.id] or 1
		label:set_text(W.loc(def.choices[index] or def.choices[1]))
		label:set_color(index == 1 and W.COLORS.off or row.color)
	end

	function row.select(index)
		local function apply()
			PD2Basic.set_setting(def.id, index)
			row.refresh()
		end
		if index ~= 1 then
			W.confirm_risk(def, apply)
		else
			apply()
		end
	end

	function row.press(x, y, button)
		if button == W.RIGHT_BUTTON then
			local count = #def.choices
			local index = PD2Basic.settings[def.id] or 1
			row.select((index - 2) % count + 1)
			return
		end
		return "dropdown"
	end

	function row.options()
		local list = {}
		for i, key in ipairs(def.choices) do
			table.insert(list, { label = W.loc(key), selected = i == (PD2Basic.settings[def.id] or 1) })
		end
		return list
	end

	row.refresh()
	apply_client_limit(row, label, { arrow })
	return row
end

function W.action(parent, y, w, def, color)
	local row = make_row(parent, y, w, def, color)
	local label = value_label(row, w)
	label:set_text(">")
	label:set_color(row.color)

	function row.refresh() end

	function row.press(x, y, button)
		local action = PD2Basic.actions[def.action]
		if not action then
			PD2Basic.say("error", tostring(def.action), "not found")
			return
		end
		W.confirm_risk(def, function()
			action(def)
		end)
	end

	apply_client_limit(row, label)
	return row
end

function W.language(parent, y, w, def, color)
	local row = make_row(parent, y, w, def, color)
	local label = value_label(row, w)

	function row.refresh()
		label:set_text(PD2Basic.settings.language == "ru" and "РУССКИЙ" or "ENGLISH")
		label:set_color(row.color)
	end

	function row.press()
		PD2Basic.set_setting("language", PD2Basic.settings.language == "ru" and "en" or "ru")
		PD2Basic.Overlay.refresh_page()
	end

	row.refresh()
	return row
end

function W.hotkey(parent, y, w, def, color)
	local row = make_row(parent, y, w, def, color)
	local box = row.panel:rect({ x = w * 0.62, y = 4, w = w * 0.38 - 8, h = W.ROW_H - 8, color = W.COLORS.field, layer = 1 })
	local label = text(row.panel, { text = "", x = w * 0.62, w = w * 0.38 - 8, align = "center" })
	row.desc = row.desc .. "  " .. W.loc("pd2basic_hotkey_hint")

	function row.refresh()
		local capture = PD2Basic.Hotkeys._capture
		local waiting = capture and capture.id == def.id
		label:set_text(waiting and W.loc("pd2basic_hotkey_press") or PD2Basic.Hotkeys.key_label(def.id))
		label:set_color(waiting and W.COLORS.warning or (PD2Basic.hotkeys[def.id] and row.color or W.COLORS.dim))
		box:set_color(waiting and W.COLORS.warning:with_alpha(0.2) or W.COLORS.field)
	end

	function row.press()
		PD2Basic.Hotkeys.capture(def.id, function()
			PD2Basic.Overlay.refresh_page()
		end)
		row.refresh()
	end

	row.refresh()
	return row
end

local function text_field(row, w, def, opts)
	local box_x = opts.box_x
	local box = row.panel:rect({ x = box_x, y = 3, w = w - box_x - 4, h = W.ROW_H - 6, color = W.COLORS.field, layer = 1 })
	local label = text(row.panel, { text = "", x = box_x + 8, w = w - box_x - 20, align = opts.align or "right" })

	function row.refresh()
		local value = PD2Basic.inputs[def.id] or ""
		if value == "" and not row.focused and opts.placeholder then
			label:set_text(opts.placeholder)
			label:set_color(W.COLORS.dim)
		else
			label:set_text(row.focused and (value .. "_") or value)
			label:set_color(W.COLORS.text)
		end
		box:set_color(row.focused and row.color:with_alpha(0.3) or W.COLORS.field)
	end

	local function changed()
		row.refresh()
		if opts.on_change then
			opts.on_change()
		end
	end

	function row.press()
		return "focus"
	end

	function row.set_focus(state)
		row.focused = state
		row.refresh()
	end

	function row.enter_text(s)
		if s:match(opts.pattern) then
			local value = PD2Basic.inputs[def.id] or ""
			if opts.numeric and value == "0" then
				value = ""
			end
			if #value < opts.max_len then
				PD2Basic.inputs[def.id] = value .. s
			end
			changed()
		end
	end

	function row.key_press(k)
		if k == Idstring("backspace") then
			local value = PD2Basic.inputs[def.id] or ""
			PD2Basic.inputs[def.id] = value:sub(1, -2)
			changed()
		elseif k == Idstring("enter") or k == Idstring("esc") then
			return true
		end
		return false
	end
end

function W.number(parent, y, w, def, color)
	local row = make_row(parent, y, w, def, color)
	row.desc = row.desc .. "  " .. W.loc("pd2basic_number_hint")
	if PD2Basic.inputs[def.id] == nil then
		PD2Basic.inputs[def.id] = tostring(def.default or 0)
	end
	text_field(row, w, def, { pattern = "^%d$", max_len = 12, numeric = true, box_x = w * 0.5 })
	row.refresh()
	return row
end

function W.search(parent, y, w, def, color)
	local row = make_row(parent, y, w, def, color)
	row.desc = row.desc .. "  " .. W.loc("pd2basic_search_hint")
	text_field(row, w, def, {
		pattern = "^[%w_%-%. ]$",
		max_len = 32,
		box_x = math.min(w * 0.35, 140),
		align = "left",
		placeholder = W.loc("pd2basic_search_placeholder"),
		on_change = function()
			PD2Basic.Overlay.on_input_changed(def.id)
		end,
	})
	row.refresh()
	return row
end

W.GROUP_H = 30

function W.group(parent, x, y, w, group, widgets)
	local color = W.GROUP_COLORS[group.id] or W.COLORS.accent
	local card = parent:panel({ x = x, y = y, w = w, h = 1000 })
	card:rect({ color = W.COLORS.card, layer = 0 })
	text(card, {
		text = W.loc("pd2basic_group_" .. group.id):upper(),
		font = W.font_bold(),
		font_size = W.font_size() * 0.9,
		color = color,
		x = 10,
		y = 2,
		w = w - 20,
		h = W.GROUP_H - 6,
		align = "center",
	})
	local line_y = W.GROUP_H - 4
	local steps = 8
	local seg_w = (w / 2) / steps
	for i = 0, steps - 1 do
		local alpha = (1 - i / steps) * 0.9
		card:rect({ x = w / 2 + i * seg_w, y = line_y, w = seg_w, h = 2, color = color:with_alpha(alpha), layer = 1 })
		card:rect({ x = w / 2 - (i + 1) * seg_w, y = line_y, w = seg_w, h = 2, color = color:with_alpha(alpha), layer = 1 })
	end
	local items = W.visible_items(group)
	local columns = group.columns or 1
	local per_column = math.ceil(#items / columns)
	local gap = columns > 1 and 10 or 0
	local col_w = math.floor((w - gap * (columns - 1)) / columns)
	local top = W.GROUP_H + 2
	local holders = {}
	for c = 1, columns do
		holders[c] = columns > 1 and card:panel({ x = (c - 1) * (col_w + gap), y = 0, w = col_w, h = 1000 }) or card
	end
	for i, def in ipairs(items) do
		local c = math.floor((i - 1) / per_column) + 1
		local row_y = top + ((i - 1) % per_column) * W.ROW_H
		table.insert(widgets, W[def.kind](holders[c], row_y, col_w, def, color))
	end
	local h = top + per_column * W.ROW_H + 6
	for c = 2, columns do
		holders[c]:set_h(h)
	end
	if columns > 1 then
		holders[1]:set_h(h)
	end
	card:set_h(h)
	return h
end

W.LIST_ROW_H = 26

function W.list(parent, y, w, def, color)
	color = color or W.COLORS.accent
	local rows = def.rows or 6
	local h = rows * W.LIST_ROW_H
	local widget = {}
	widget.panel = parent:panel({ x = 0, y = y, w = w, h = h })
	widget.panel:rect({ color = W.COLORS.card, layer = 0 })
	widget.desc = W.loc("pd2basic_" .. def.id .. "_desc")
	widget.height = h
	widget.search_id = def.search

	local source = PD2Basic.sources[def.source]
	local ok, all_items = pcall(source or function() return {} end)
	if not ok then
		PD2Basic.log("ERROR building list " .. tostring(def.source) .. ": " .. tostring(all_items))
		all_items = {}
	end
	local items = all_items

	local offset = 0
	local labels = {}
	local highlights = {}
	for i = 1, rows do
		highlights[i] = widget.panel:rect({ y = (i - 1) * W.LIST_ROW_H, h = W.LIST_ROW_H, color = W.COLORS.row, layer = 1 })
		labels[i] = text(widget.panel, { text = "", x = 10, y = (i - 1) * W.LIST_ROW_H, w = w - 30, h = W.LIST_ROW_H })
	end

	local BAR_W = 10
	local track = widget.panel:rect({ x = w - BAR_W, w = BAR_W, h = h, color = W.COLORS.field, layer = 2 })
	local scrollbar = widget.panel:rect({ x = w - BAR_W + 2, w = BAR_W - 4, h = h, color = color, layer = 3 })

	function widget.refresh()
		local selected = PD2Basic.inputs[def.id]
		for i = 1, rows do
			local item = items[offset + i]
			labels[i]:set_text(item and item.label or "")
			local is_selected = item and item.id == selected
			labels[i]:set_color(is_selected and color or W.COLORS.text)
			highlights[i]:set_color(is_selected and color:with_alpha(0.15) or W.COLORS.row)
		end
		if #items == 0 then
			labels[1]:set_text(W.loc("pd2basic_list_empty"))
			labels[1]:set_color(W.COLORS.dim)
		end
		local scrollable = #items > rows
		scrollbar:set_visible(scrollable)
		track:set_visible(scrollable)
		if scrollable then
			local bar_h = math.max(16, h * rows / #items)
			scrollbar:set_h(bar_h)
			scrollbar:set_y((h - bar_h) * offset / (#items - rows))
		end
	end

	function widget.refilter()
		local query = def.search and (PD2Basic.inputs[def.search] or ""):lower() or ""
		if query == "" then
			items = all_items
		else
			items = {}
			for _, item in ipairs(all_items) do
				if item.label:lower():find(query, 1, true) or tostring(item.id):lower():find(query, 1, true) then
					table.insert(items, item)
				end
			end
		end
		offset = 0
		widget.refresh()
	end

	function widget.scroll(direction)
		offset = math.clamp(offset + direction * 3, 0, math.max(0, #items - rows))
		widget.refresh()
	end

	local function scroll_to(y_pos)
		local max_offset = math.max(0, #items - rows)
		local ratio = math.clamp((y_pos - widget.panel:world_y()) / h, 0, 1)
		offset = math.floor(ratio * max_offset + 0.5)
		widget.refresh()
	end

	function widget.drag(x, y_pos)
		scroll_to(y_pos)
	end

	function widget.release() end

	function widget.press(x, y_pos, button)
		if #items > rows and x >= widget.panel:world_x() + w - BAR_W - 4 then
			scroll_to(y_pos)
			return true
		end
		local index = math.floor((y_pos - widget.panel:world_y()) / W.LIST_ROW_H) + 1
		local item = items[offset + index]
		if item then
			PD2Basic.inputs[def.id] = item.id
			widget.refresh()
		end
	end

	function widget.set_hover() end

	widget.refilter()
	return widget
end

function W.button(parent, x, y, w, h, label, on_press, desc, opts)
	opts = opts or {}
	local bg = opts.bg or W.COLORS.row
	local hover_bg = opts.hover or W.COLORS.row_hover
	local btn = {}
	btn.panel = parent:panel({ x = x, y = y, w = w, h = h })
	btn.hover_rect = btn.panel:rect({ color = bg, layer = 0 })
	btn.text = text(btn.panel, {
		text = label,
		font = opts.font or W.font(),
		font_size = opts.font_size or W.font_size() * 0.9,
		color = opts.color or W.COLORS.text,
		align = "center",
		layer = 1,
	})
	btn.desc = desc or ""
	function btn.set_colors(new_bg, new_text)
		bg = new_bg or bg
		btn.hover_rect:set_color(bg)
		if new_text then
			btn.text:set_color(new_text)
		end
	end
	function btn.set_hover(hover)
		btn.hover_rect:set_color(hover and hover_bg or bg)
	end
	function btn.press(x, y, button)
		on_press(btn, button)
	end
	return btn
end
