local MUL = { "pd2basic_off", "pd2basic_x1_5", "pd2basic_x2", "pd2basic_x3" }
local MUL_BIG = { "pd2basic_off", "pd2basic_x2", "pd2basic_x5", "pd2basic_x10" }

local function toggle(id)
	return { kind = "toggle", id = id }
end

local function choice(id, choices)
	return { kind = "choice", id = id, choices = choices }
end

local function action(id, name)
	return { kind = "action", id = id, action = name or id }
end

local function menu_only(def)
	def.menu_only = true
	return def
end

PD2Basic.SCREENS = {
	{
		id = "player",
		context = "game",
		columns = {
			{
				{ id = "player", items = {
					choice("god_mode", { "pd2basic_off", "pd2basic_god_immortal", "pd2basic_god_untouchable", "pd2basic_god_buddha" }),
					toggle("auto_revive"),
					toggle("no_fall_damage"),
					toggle("infinite_stamina"),
					action("heal_now", "heal"),
					action("revive_now", "revive"),
				} },
			},
			{
				{ id = "movement", items = {
					choice("speed_mode", MUL),
					choice("jump_mode", MUL),
					toggle("noclip"),
					action("teleport_now", "teleport"),
				} },
			},
			{
				{ id = "interaction", items = {
					toggle("instant_interaction"),
					choice("interaction_speed_mode", { "pd2basic_off", "pd2basic_x1_5", "pd2basic_x2", "pd2basic_x3", "pd2basic_x5" }),
					toggle("interact_through_walls"),
					toggle("interact_anything"),
					choice("interact_distance_mode", MUL_BIG),
				} },
			},
		},
	},
	{
		id = "weapons",
		context = "game",
		columns = {
			{
				{ id = "weapons", items = {
					choice("ammo_mode", { "pd2basic_off", "pd2basic_ammo_no_consume", "pd2basic_ammo_no_reload" }),
					toggle("no_recoil"),
					toggle("no_spread"),
					choice("damage_mode", { "pd2basic_off", "pd2basic_x2", "pd2basic_x5", "pd2basic_x10", "pd2basic_one_shot" }),
					choice("fire_rate_mode", MUL),
					toggle("always_critical"),
				} },
			},
			{
				{ id = "consumables", items = {
					toggle("infinite_throwables"),
					toggle("infinite_deployables"),
					toggle("infinite_cable_ties"),
					toggle("infinite_body_bags"),
					toggle("infinite_mission_items"),
					action("refill_consumables"),
				} },
			},
			{
				{ id = "bags", items = {
					toggle("bags_no_weight"),
					toggle("bags_unlimited"),
				} },
				{ id = "melee", items = {
					choice("melee_damage_mode", MUL_BIG),
					choice("melee_range_mode", { "pd2basic_off", "pd2basic_x2", "pd2basic_x3", "pd2basic_x5" }),
					toggle("melee_instant_charge"),
					toggle("melee_no_cooldown"),
				} },
				{ id = "sentries", items = {
					toggle("sentry_infinite_ammo"),
					toggle("sentry_invulnerable"),
				} },
			},
		},
	},
	{
		id = "stealth",
		context = "game",
		columns = {
			{
				{ id = "stealth", items = {
					toggle("invisible"),
					toggle("no_alarm"),
					toggle("cameras_no_detection"),
					toggle("infinite_camera_loops"),
					toggle("endless_camera_loops"),
					toggle("disable_lasers"),
				} },
				{ id = "pagers", items = {
					toggle("infinite_pagers"),
					toggle("pager_bluff_success"),
					toggle("no_pagers"),
					action("answer_pagers"),
				} },
			},
			{
				{ id = "esp", items = {
					toggle("esp_enabled"),
					toggle("esp_cops"),
					toggle("esp_guards"),
					toggle("esp_civilians"),
					toggle("esp_cameras"),
					toggle("esp_loot"),
					toggle("esp_key_holders"),
				} },
				{ id = "timers", items = {
					toggle("timer_camera_loops"),
					toggle("timer_pagers"),
					toggle("timer_ecm"),
				} },
			},
			{
				{ id = "hostages", items = {
					action("tie_all_civilians"),
					action("convert_all_enemies"),
					toggle("unlimited_jokers"),
					toggle("instant_domination"),
				} },
				{ id = "ai", items = {
					toggle("freeze_ai"),
					toggle("ai_no_shoot"),
				} },
			},
		},
	},
	{
		id = "world",
		context = "game",
		columns = {
			{
				{ id = "world", items = {
					action("kill_all_enemies"),
					action("finish_timers"),
					action("bag_all_corpses"),
					toggle("drills_never_jam"),
				} },
			},
			{
				{ id = "loot", items = {
					action("secure_all_bags"),
					action("pickup_small_loot"),
					action("collect_gage_packages"),
				} },
			},
			{
				{ id = "heist", items = {
					toggle("freeze_ponr"),
					action("win_heist"),
				} },
				{ id = "map", items = {
					action("open_all_doors"),
					action("open_deposit_boxes"),
					action("open_atms"),
					action("answer_phones"),
				} },
			},
		},
	},
	{
		id = "spawn",
		context = "game",
		spawn = true,
	},
	{
		id = "profile",
		context = "any",
		columns = {
			{
				{ id = "money", items = {
					{ kind = "number", menu_only = true, id = "money_amount", default = 10000000 },
					menu_only(action("add_spending")),
					menu_only(action("add_offshore")),
				} },
				{ id = "heist_rewards", items = {
					choice("money_mode", MUL_BIG),
					choice("xp_mode", MUL_BIG),
					toggle("no_civilian_penalty"),
				} },
			},
			{
				{ id = "level", items = {
					{ kind = "number", menu_only = true, id = "xp_amount", default = 1000000 },
					menu_only(action("add_xp")),
					menu_only(action("max_level")),
					{ kind = "number", menu_only = true, id = "infamy_rank", default = 25 },
					menu_only(action("set_infamy")),
				} },
				{ id = "points", items = {
					{ kind = "number", menu_only = true, id = "points_amount", default = 10 },
					menu_only(action("add_skill_points")),
					menu_only(action("add_perk_points")),
				} },
				{ id = "shop", items = {
					toggle("free_purchases"),
				} },
			},
			{
				{ id = "inventory", items = {
					menu_only(action("complete_gage")),
					menu_only(action("unlock_slots")),
					{ kind = "number", menu_only = true, id = "inventory_amount", default = 1 },
					menu_only(action("add_masks")),
					menu_only(action("add_materials")),
					menu_only(action("add_patterns")),
					menu_only(action("add_colors")),
					menu_only(action("add_weapon_mods")),
				} },
			},
		},
	},
	{
		id = "config",
		context = "any",
		config = true,
	},
}

PD2Basic.SPAWN_MODES = {
	{
		id = "spawn_items",
		search = { kind = "search", id = "spawn_search" },
		list = { kind = "list", id = "spawn_list", source = "spawnables", search = "spawn_search", rows = 14 },
		buttons = { action("give_selected"), action("spawn_bag") },
	},
	{
		id = "spawn_elements",
		search = { kind = "search", id = "element_search" },
		list = { kind = "list", id = "element_list", source = "mission_elements", search = "element_search", rows = 14 },
		buttons = { action("run_element") },
	},
}

function PD2Basic.screen_available(screen, context)
	return screen.context == "any" or screen.context == context
end

function PD2Basic.first_screen_for(context)
	for _, screen in ipairs(PD2Basic.SCREENS) do
		if PD2Basic.screen_available(screen, context) then
			return screen
		end
	end
end

function PD2Basic.screen_by_id(id)
	for _, screen in ipairs(PD2Basic.SCREENS) do
		if screen.id == id then
			return screen
		end
	end
	return nil
end
