if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local MAIN_MENU = "pd2basic_menu"

Hooks:Add("LocalizationManagerPostInit", "PD2Basic_Localization", function(loc)
	PD2Basic.safe_call("localization", function()
		local strings = {}
		for key, value in pairs(PD2Basic.strings.en or {}) do
			strings[key] = PD2Basic.text(key)
		end
		loc:add_localized_strings(strings)
	end)
end)

function MenuCallbackHandler:pd2basic_open_overlay()
	PD2Basic.safe_call("open overlay button", function()
		if Utils:IsInGameState() then
			managers.menu:close_menu("menu_pause")
			DelayedCalls:Add("PD2Basic_OpenOverlay", 0.2, function()
				PD2Basic.safe_call("open overlay delayed", PD2Basic.Overlay.open)
			end)
		else
			PD2Basic.Overlay.open()
		end
	end)
end

Hooks:Add("MenuManagerSetupCustomMenus", "PD2Basic_SetupMenus", function(menu_manager, nodes)
	PD2Basic.safe_call("setup menus", function()
		MenuHelper:NewMenu(MAIN_MENU)
	end)
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "PD2Basic_PopulateMenus", function(menu_manager, nodes)
	PD2Basic.safe_call("populate menus", function()
		MenuHelper:AddButton({
			id = "pd2basic_open_overlay",
			title = "pd2basic_open_overlay_title",
			desc = "pd2basic_open_overlay_desc",
			callback = "pd2basic_open_overlay",
			menu_id = MAIN_MENU,
			priority = 100,
		})
	end)
end)

Hooks:Add("MenuManagerBuildCustomMenus", "PD2Basic_BuildMenus", function(menu_manager, nodes)
	PD2Basic.safe_call("build menus", function()
		nodes[MAIN_MENU] = MenuHelper:BuildMenu(MAIN_MENU)
		MenuHelper:AddMenuItem(nodes["blt_options"], MAIN_MENU, "pd2basic_menu_title", "pd2basic_menu_desc")
		PD2Basic.log("menu built")
	end)
end)
