if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

Hooks:PostHook(GameSetup, "init_finalize", "PD2Basic_GameSetupInit", function(self)
	PD2Basic.safe_call("game setup", function()
		if PD2Basic.settings.reset_each_heist then
			PD2Basic.reset_cheats()
			PD2Basic.log("cheats reset for new heist")
		end
		local allowed, reason = PD2Basic.is_allowed()
		PD2Basic.log("allowed: " .. tostring(allowed) .. " (" .. tostring(reason) .. "), master_enabled: " .. tostring(PD2Basic.settings.master_enabled))
	end)
end)
