local SAVE_FILE = SavePath .. "pd2basic.json"
local OLD_SAVE_FILE = SavePath .. "deadly_trainer.json"

PD2Basic.defaults = {
	master_enabled = false,

	language = "en",
	reset_each_heist = true,

	god_mode = 1,
	auto_revive = false,
	no_fall_damage = false,
	infinite_stamina = false,

	speed_mode = 1,
	jump_mode = 1,
	noclip = false,

	ammo_mode = 1,
	no_recoil = false,
	no_spread = false,
	damage_mode = 1,
	fire_rate_mode = 1,
	always_critical = false,

	melee_damage_mode = 1,
	melee_range_mode = 1,
	melee_instant_charge = false,
	melee_no_cooldown = false,

	sentry_infinite_ammo = false,
	sentry_invulnerable = false,

	instant_interaction = false,
	interaction_speed_mode = 1,
	interact_through_walls = false,
	interact_anything = false,
	interact_distance_mode = 1,

	no_alarm = false,
	invisible = false,
	cameras_no_detection = false,
	infinite_camera_loops = false,
	endless_camera_loops = false,
	disable_lasers = false,
	no_pagers = false,

	freeze_ai = false,
	ai_no_shoot = false,
	infinite_pagers = false,
	pager_bluff_success = false,

	infinite_throwables = false,
	infinite_deployables = false,
	infinite_cable_ties = false,
	infinite_body_bags = false,
	infinite_mission_items = false,

	unlimited_jokers = false,
	instant_domination = false,

	drills_never_jam = false,
	freeze_ponr = false,
	money_mode = 1,
	xp_mode = 1,
	no_civilian_penalty = false,
	free_purchases = false,

	bags_no_weight = false,
	bags_unlimited = false,

	esp_enabled = false,
	esp_cameras = false,
	esp_loot = false,
	esp_cops = false,
	esp_civilians = false,
	esp_guards = false,
	esp_key_holders = false,

	timer_camera_loops = false,
	timer_pagers = false,
	timer_ecm = false,
}

PD2Basic.settings = {}

PD2Basic.presets = {}

PD2Basic.hotkeys = {}
PD2Basic.default_hotkeys = { open_main = "num 1" }

local function merge_with_defaults(saved)
	local result = {}
	for key, value in pairs(PD2Basic.defaults) do
		result[key] = value
		if type(saved) == "table" and saved[key] ~= nil and type(saved[key]) == type(value) then
			result[key] = saved[key]
		end
	end
	return result
end

function PD2Basic.load_settings()
	local saved = nil
	local migrate = false
	local file = io.open(SAVE_FILE, "r")
	if not file then
		file = io.open(OLD_SAVE_FILE, "r")
		migrate = file ~= nil
	end
	if file then
		local content = file:read("*all")
		file:close()
		local ok, decoded = pcall(json.decode, content)
		if ok and type(decoded) == "table" then
			saved = decoded
		else
			PD2Basic.log("ERROR: cannot parse " .. SAVE_FILE .. ", using defaults")
		end
	end
	PD2Basic.settings = merge_with_defaults(saved)
	PD2Basic.hotkeys = {}
	local saved_keys = type(saved) == "table" and type(saved.hotkeys) == "table" and saved.hotkeys or PD2Basic.default_hotkeys
	for action, key in pairs(saved_keys) do
		if type(key) == "string" and key ~= "" then
			PD2Basic.hotkeys[action] = key
		end
	end
	PD2Basic.presets = {}
	if type(saved) == "table" and type(saved.presets) == "table" then
		for name, preset in pairs(saved.presets) do
			if type(preset) == "table" then
				PD2Basic.presets[name] = merge_with_defaults(preset)
			end
		end
	end
	if migrate and saved then
		PD2Basic.save_settings()
		PD2Basic.log("settings moved from " .. OLD_SAVE_FILE .. " to " .. SAVE_FILE)
	end
end

function PD2Basic.save_settings()
	local file = io.open(SAVE_FILE, "w+")
	if not file then
		PD2Basic.log("ERROR: cannot write " .. SAVE_FILE)
		return
	end
	local data = {}
	for key, value in pairs(PD2Basic.settings) do
		data[key] = value
	end
	data.presets = PD2Basic.presets
	data.hotkeys = PD2Basic.hotkeys
	file:write(json.encode(data))
	file:close()
end

function PD2Basic.settings_summary()
	local parts = {}
	for key, value in pairs(PD2Basic.settings) do
		if value ~= PD2Basic.defaults[key] then
			table.insert(parts, key .. "=" .. tostring(value))
		end
	end
	table.sort(parts)
	if #parts == 0 then
		return "all defaults (everything off)"
	end
	return table.concat(parts, ", ")
end

function PD2Basic.set_setting(key, value)
	if PD2Basic.defaults[key] == nil then
		PD2Basic.log("ERROR: unknown setting " .. tostring(key))
		return
	end
	PD2Basic.settings[key] = value
	PD2Basic.save_settings()
	PD2Basic.log("setting " .. key .. " = " .. tostring(value))
end

function PD2Basic.reset_cheats()
	for key, value in pairs(PD2Basic.defaults) do
		if not PD2Basic.PERSISTENT[key] then
			PD2Basic.settings[key] = value
		end
	end
	PD2Basic.save_settings()
end
