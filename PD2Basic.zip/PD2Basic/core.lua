if PD2Basic then
	return
end

PD2Basic = {}
PD2Basic.path = ModPath
PD2Basic.version = "1.2.1"

PD2Basic.MULTIPLIERS = {
	speed_mode = { 1, 1.5, 2, 3 },
	jump_mode = { 1, 1.5, 2, 3 },
	damage_mode = { 1, 2, 5, 10 },
	fire_rate_mode = { 1, 1.5, 2, 3 },
	interact_distance_mode = { 1, 2, 5, 10 },
	interaction_speed_mode = { 1, 1.5, 2, 3, 5 },
	melee_damage_mode = { 1, 2, 5, 10 },
	melee_range_mode = { 1, 2, 3, 5 },
	money_mode = { 1, 2, 5, 10 },
	xp_mode = { 1, 2, 5, 10 },
}

function PD2Basic.multiplier(key)
	if PD2Basic.PERSISTENT[key] then
		if not PD2Basic.settings.master_enabled then
			return 1
		end
	elseif not PD2Basic.is_enabled(key) then
		return 1
	end
	return PD2Basic.MULTIPLIERS[key][PD2Basic.settings[key]] or 1
end

PD2Basic.actions = {}
PD2Basic.sources = {}
PD2Basic.inputs = {}

PD2Basic.strings = {}

local function load_strings(lang, file)
	local f = io.open(PD2Basic.path .. "loc/" .. file, "r")
	if not f then
		PD2Basic.strings[lang] = {}
		return
	end
	local content = f:read("*all")
	f:close()
	local ok, data = pcall(json.decode, content)
	PD2Basic.strings[lang] = ok and type(data) == "table" and data or {}
end

function PD2Basic.load_languages()
	load_strings("en", "english.json")
	load_strings("ru", "russian.json")
end

function PD2Basic.text(key)
	local lang = PD2Basic.settings and PD2Basic.settings.language or "en"
	local value = PD2Basic.strings[lang] and PD2Basic.strings[lang][key]
	if value == nil then
		value = PD2Basic.strings.en and PD2Basic.strings.en[key]
	end
	return value or key
end

function PD2Basic.log(msg)
	log("[PD2Basic] " .. tostring(msg))
end

function PD2Basic.safe_call(tag, func, ...)
	local ok, result = pcall(func, ...)
	if not ok then
		PD2Basic.log("ERROR in " .. tostring(tag) .. ": " .. tostring(result))
		return nil
	end
	return result
end

local permission_cache = { t = -1, value = nil }

local function lobby_permission(is_host)
	local gs = Global.game_settings
	if is_host then
		return gs.permission
	end
	local now = Application:time()
	if now - permission_cache.t < 1 then
		return permission_cache.value
	end
	permission_cache.t = now
	permission_cache.value = nil
	pcall(function()
		local handler = managers.network.matchmake.lobby_handler
		local index = handler and tonumber(handler:get_lobby_data("permission"))
		permission_cache.value = index and tweak_data:index_to_permission(index)
	end)
	return permission_cache.value
end

function PD2Basic.is_allowed()
	local gs = Global.game_settings
	if not gs then
		return false, "no game settings"
	end
	if gs.single_player then
		return true, "offline"
	end
	local is_host = Network and Network:is_server()
	local role = is_host and "host" or "client"
	local permission = lobby_permission(is_host)
	if permission == "private" then
		return true, "private " .. role
	end
	if permission == "friends_only" then
		return true, "friends-only " .. role
	end
	return false, "lobby is " .. tostring(permission)
end

PD2Basic.CLIENT_LIMITS = {
	cameras_no_detection = "host",
	infinite_camera_loops = "host",
	endless_camera_loops = "host",
	no_pagers = "host",
	freeze_ai = "host",
	ai_no_shoot = "host",
	instant_domination = "host",
	sentry_infinite_ammo = "host",
	sentry_invulnerable = "host",
	melee_damage_mode = "mod",
	melee_range_mode = "mod",
	melee_instant_charge = "mod",
	melee_no_cooldown = "mod",
	always_critical = "mod",
	infinite_pagers = "host",
	pager_bluff_success = "host",
	no_alarm = "host",
	drills_never_jam = "host",
	freeze_ponr = "host",

	bags_unlimited = "host",
	spawn_bag = "host",
	kill_all_enemies = "host",
	tie_all_civilians = "host",
	convert_all_enemies = "host",
	finish_timers = "host",
	secure_all_bags = "host",
	bag_all_corpses = "host",
	pickup_small_loot = "host",
	win_heist = "host",
	run_element = "host",

	infinite_deployables = "cheater",
	infinite_throwables = "cheater",
	refill_consumables = "cheater",

	noclip = "mod",
	teleport_now = "mod",
	speed_mode = "mod",
	jump_mode = "mod",
	invisible = "mod",
	damage_mode = "mod",
	fire_rate_mode = "mod",
	interact_through_walls = "mod",
	interact_distance_mode = "mod",
	interact_anything = "mod",
}

function PD2Basic.client_limit(key)
	local limit = PD2Basic.CLIENT_LIMITS[key]
	if not limit or not Network or Network:is_server() then
		return nil
	end
	if Global.game_settings and Global.game_settings.single_player then
		return nil
	end
	return limit
end

function PD2Basic.blocked_as_client(key)
	return PD2Basic.client_limit(key) == "host"
end

function PD2Basic.client_risk(key)
	local limit = PD2Basic.client_limit(key)
	if limit == "cheater" or limit == "mod" then
		return limit
	end
	return nil
end

PD2Basic.PERSISTENT = {
	master_enabled = true,
	language = true,
	reset_each_heist = true,
	money_mode = true,
	xp_mode = true,
	no_civilian_penalty = true,
	free_purchases = true,
}

function PD2Basic.profile_enabled(key)
	local s = PD2Basic.settings
	return s ~= nil and s.master_enabled and s[key] == true
end

function PD2Basic.is_enabled(key)
	local s = PD2Basic.settings
	if not s or not s.master_enabled then
		return false
	end
	local value = s[key]
	if value == nil or value == false or value == 1 then
		return false
	end
	if PD2Basic.blocked_as_client(key) then
		return false
	end
	return (PD2Basic.is_allowed())
end

function PD2Basic.notify(msg)
	PD2Basic.log(msg)
	if PD2Basic.Overlay and PD2Basic.Overlay.show_message and PD2Basic.Overlay.is_open() then
		PD2Basic.Overlay.show_message(msg)
	elseif Utils:IsInGameState() and managers.hud and managers.hud.show_hint then
		managers.hud:show_hint({ text = msg })
	end
end

function PD2Basic.say(key, ...)
	local template = PD2Basic.text("pd2basic_msg_" .. key)
	local ok, msg = pcall(string.format, template, ...)
	PD2Basic.notify(ok and msg or template)
end

local REASON_KEYS = {
	["offline"] = "offline",
	["private host"] = "private_host",
	["private client"] = "private_client",
	["friends-only host"] = "friends_host",
	["friends-only client"] = "friends_client",
	["lobby is public"] = "public",
}

function PD2Basic.reason_text(reason)
	local key = REASON_KEYS[reason]
	if key then
		return PD2Basic.text("pd2basic_reason_" .. key)
	end
	return PD2Basic.text("pd2basic_reason_other")
end

function PD2Basic.game_player()
	if not PD2Basic.settings.master_enabled then
		PD2Basic.say("master_off")
		return nil
	end
	local allowed, reason = PD2Basic.is_allowed()
	if not allowed then
		PD2Basic.say("blocked", PD2Basic.reason_text(reason))
		return nil
	end
	local player = managers.player and managers.player:player_unit()
	if not alive(player) then
		PD2Basic.say("no_player")
		return nil
	end
	return player
end

function PD2Basic.register_action(name, func)
	PD2Basic.actions[name] = function(...)
		local ok, err = pcall(func, ...)
		if not ok then
			PD2Basic.say("error", name, tostring(err))
		end
	end
end

function PD2Basic.input_number(id, default)
	local value = tonumber(PD2Basic.inputs[id])
	if value == nil then
		return default
	end
	return value
end

dofile(PD2Basic.path .. "settings.lua")
dofile(PD2Basic.path .. "menu/definitions.lua")
dofile(PD2Basic.path .. "ui/widgets.lua")
dofile(PD2Basic.path .. "ui/overlay.lua")

dofile(PD2Basic.path .. "features/player_actions.lua")
dofile(PD2Basic.path .. "features/spawn_items.lua")
dofile(PD2Basic.path .. "features/mission_tools.lua")
dofile(PD2Basic.path .. "features/profile_editor.lua")
dofile(PD2Basic.path .. "features/gage.lua")
dofile(PD2Basic.path .. "features/blackmarket.lua")
dofile(PD2Basic.path .. "features/presets.lua")
dofile(PD2Basic.path .. "features/world_actions.lua")
dofile(PD2Basic.path .. "features/teleport.lua")
dofile(PD2Basic.path .. "features/hotkeys.lua")
PD2Basic.load_settings()
PD2Basic.load_languages()
PD2Basic.log("loaded v" .. PD2Basic.version .. ", settings: " .. PD2Basic.settings_summary())
