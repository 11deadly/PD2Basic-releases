if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local function on()
	return PD2Basic.is_enabled("interact_anything")
end

if RequiredScript == "lib/units/interactions/interactionext" then
	local orig_upgrade = BaseInteractionExt._has_required_upgrade
	function BaseInteractionExt:_has_required_upgrade(...)
		if on() then
			return true
		end
		return orig_upgrade(self, ...)
	end

	local orig_deployable = BaseInteractionExt._has_required_deployable
	function BaseInteractionExt:_has_required_deployable(...)
		if on() then
			return true
		end
		return orig_deployable(self, ...)
	end

	local METHODS = { "can_interact", "can_select", "selected", "update_show_interact", "interact_start", "interact" }

	local function finish(previous, ok, ...)
		PD2Basic._interact_bypass = previous
		if not ok then
			error((...), 0)
		end
		return ...
	end

	local function wrap(class, method)
		local orig = rawget(class, method)
		if type(orig) ~= "function" then
			return
		end
		class[method] = function(self, ...)
			if not on() then
				return orig(self, ...)
			end
			local previous = PD2Basic._interact_bypass
			PD2Basic._interact_bypass = self._tweak_data
			return finish(previous, pcall(orig, self, ...))
		end
	end

	for name, class in pairs(_G) do
		if type(name) == "string" and name:find("InteractionExt$") and type(class) == "table" then
			for _, method in ipairs(METHODS) do
				wrap(class, method)
			end
		end
	end
	return
end

if RequiredScript == "lib/managers/playermanager" then
	local function needed(tweak, name)
		if tweak.special_equipment == name then
			return true
		end
		for _, item in ipairs(tweak.possible_special_equipment or {}) do
			if item == name then
				return true
			end
		end
		return false
	end

	local orig_has_special = PlayerManager.has_special_equipment
	function PlayerManager:has_special_equipment(name, ...)
		local real = orig_has_special(self, name, ...)
		if real then
			return real
		end
		local tweak = PD2Basic._interact_bypass
		if tweak and needed(tweak, name) and on() then
			return { amount = Application:digest_value(1, true) }
		end
		return real
	end
end
