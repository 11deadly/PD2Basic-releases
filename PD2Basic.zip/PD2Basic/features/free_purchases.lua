if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local PRICES = {
	"get_weapon_price_modified",
	"get_weapon_modify_price",
	"get_buy_weapon_slot_price",
	"get_buy_mask_slot_price",
	"get_mask_part_price_modified",
	"get_mask_crafting_price_modified",
	"get_mission_asset_cost_by_id",
	"get_preplanning_type_cost",
	"get_preplanning_votes_cost",
	"get_cost_of_premium_contract",
	"get_cost_of_casino_entrance",
	"get_cost_of_casino_fee",
	"get_skillpoint_cost",
	"get_unlock_skill_switch_spending_cost",
	"get_unlock_skill_switch_offshore_cost",
	"get_infamous_cost",
}

for _, method in ipairs(PRICES) do
	local orig = MoneyManager[method]
	if type(orig) == "function" then
		MoneyManager[method] = function(self, ...)
			if PD2Basic.profile_enabled("free_purchases") then
				local value = orig(self, ...)
				if type(value) == "number" then
					return 0
				end
				return value
			end
			return orig(self, ...)
		end
	end
end
