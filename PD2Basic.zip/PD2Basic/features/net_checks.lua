if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local function is_local_trainer_peer(peer)
	if not PD2Basic.settings.master_enabled or not PD2Basic.is_allowed() then
		return false
	end
	local session = managers.network and managers.network:session()
	return session and session:local_peer() == peer
end

local function bypass(method)
	local orig = NetworkPeer[method]
	NetworkPeer[method] = function(self, ...)
		if is_local_trainer_peer(self) then
			return true
		end
		return orig(self, ...)
	end
end

bypass("verify_bag")
bypass("verify_deployable")
bypass("verify_grenade")

local orig_mark_cheater = NetworkPeer.mark_cheater
function NetworkPeer:mark_cheater(reason, ...)
	if is_local_trainer_peer(self) then
		PD2Basic.log("ignored cheater mark on local peer, reason " .. tostring(reason))
		return
	end
	return orig_mark_cheater(self, reason, ...)
end
