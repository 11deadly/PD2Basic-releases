PD2Basic.register_profile_action("complete_gage", function()
	local gage = managers.gage_assignment
	local completed = 0
	for assignment, _ in pairs(tweak_data.gage_assignment:get_assignments()) do
		local dlc = tweak_data.gage_assignment:get_value(assignment, "dlc")
		if not dlc or managers.dlc:is_dlc_unlocked(dlc) then
			gage:_give_rewards(assignment)
			gage._global.active_assignments[assignment] = Application:digest_value(0, true)
			completed = completed + 1
		end
	end
	PD2Basic.say("gage_completed", completed)
end)
