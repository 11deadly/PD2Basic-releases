if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local NOCLIP_SPEED = 600
local NOCLIP_RUN_SPEED = 2000
local GRAVITY = Vector3(0, 0, -982)

local function noclip()
	return PD2Basic.is_enabled("noclip")
end

if RequiredScript == "lib/units/beings/player/states/playerstandard" then
	local orig_walk_speed = PlayerStandard._get_max_walk_speed
	function PlayerStandard:_get_max_walk_speed(...)
		return orig_walk_speed(self, ...) * PD2Basic.multiplier("speed_mode")
	end

	local orig_jump = PlayerStandard._perform_jump
	function PlayerStandard:_perform_jump(jump_vec, ...)
		local mul = PD2Basic.multiplier("jump_mode")
		if mul ~= 1 then
			jump_vec = jump_vec * mul
		end
		return orig_jump(self, jump_vec, ...)
	end

	local orig_update_movement = PlayerStandard._update_movement
	function PlayerStandard:_update_movement(t, dt, ...)
		if noclip() then
			self._unit:mover():set_velocity(Vector3())
			return
		end
		return orig_update_movement(self, t, dt, ...)
	end

	local function fly(state, dt)
		local controller = state._controller
		local camera = state._ext_camera
		if not controller or not camera then
			return
		end
		local axis = controller:get_input_axis("move")
		local rot = camera:rotation()
		local dir = camera:forward() * axis.y + rot:x() * axis.x
		if controller:get_input_bool("jump") then
			dir = dir + Vector3(0, 0, 1)
		end
		if controller:get_input_bool("duck") then
			dir = dir - Vector3(0, 0, 1)
		end
		if dir:length() < 0.01 then
			return
		end
		local speed = controller:get_input_bool("run") and NOCLIP_RUN_SPEED or NOCLIP_SPEED
		local pos = state._unit:position() + dir:normalized() * speed * dt
		state._unit:warp_to(state._unit:rotation(), pos)
	end

	local orig_update = PlayerStandard.update
	function PlayerStandard:update(t, dt, ...)
		local result = orig_update(self, t, dt, ...)
		if noclip() then
			if not self._pd2basic_noclip then
				self._pd2basic_noclip = true
				self._unit:mover():set_gravity(Vector3(0, 0, 0))
			end
			PD2Basic.safe_call("noclip", fly, self, dt)
		elseif self._pd2basic_noclip then
			self._pd2basic_noclip = nil
			self._unit:mover():set_gravity(GRAVITY)
		end
		return result
	end
end

if RequiredScript == "lib/units/beings/player/playerdamage" then
	local orig_fall = PlayerDamage.damage_fall
	function PlayerDamage:damage_fall(...)
		if noclip() or PD2Basic.is_enabled("no_fall_damage") then
			return
		end
		return orig_fall(self, ...)
	end
end

if RequiredScript == "lib/units/beings/player/playermovement" then
	local orig_subtract = PlayerMovement.subtract_stamina
	function PlayerMovement:subtract_stamina(value, ...)
		if PD2Basic.is_enabled("infinite_stamina") then
			return
		end
		return orig_subtract(self, value, ...)
	end
end
