if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

PD2Basic.Timers = PD2Basic.Timers or { ecms = setmetatable({}, { __mode = "k" }), pagers = {}, next_t = 0 }
local T = PD2Basic.Timers
local INTERVAL = 0.1
local ENDLESS = 10000
local MAX_LINES = 12

if RequiredScript == "lib/units/equipment/ecm_jammer/ecmjammerbase" then
	Hooks:PostHook(ECMJammerBase, "init", "PD2Basic_RegisterECM", function(self)
		T.ecms[self] = true
	end)
	return
end

local COLORS = {
	camera = Color(1, 0.1, 1, 1),
	pager = Color(1, 1, 0.55, 0),
	ecm = Color(1, 0.55, 0.75, 1),
}

local function average(range)
	return (range[1] + range[2]) / 2
end

local function pager_durations()
	local pager = tweak_data.player.alarm_pager
	local list = {}
	for i = 1, math.max(1, math.floor(average(pager.nr_of_calls) + 0.5)) do
		list[i] = average(pager.call_duration[math.min(#pager.call_duration, i)])
	end
	return list
end

local function host_pager_left(unit, now)
	local brain = unit:brain()
	local data = brain and brain._alarm_pager_data
	if not data or not data.pager_clbk_id then
		return nil
	end
	local exec_t = managers.enemy:get_delayed_clbk_exec_t(data.pager_clbk_id)
	if not exec_t then
		return nil
	end
	local left = exec_t - now
	local pager = tweak_data.player.alarm_pager
	for j = data.nr_calls_made + 1, data.total_nr_calls do
		left = left + average(pager.call_duration[math.min(#pager.call_duration, j)])
	end
	return left
end

local function collect_pagers(lines, now)
	local seen = {}
	local client_total = 0
	for _, d in ipairs(pager_durations()) do
		client_total = client_total + d
	end
	for _, unit in ipairs(managers.interaction._interactive_units or {}) do
		local ext = alive(unit) and unit:interaction()
		if ext and ext._active and ext.tweak_data == "corpse_alarm_pager" then
			local key = unit:key()
			seen[key] = true
			T.pagers[key] = T.pagers[key] or now
			local left
			if Network:is_server() then
				left = host_pager_left(unit, now)
			else
				left = client_total - (now - T.pagers[key])
			end
			if left then
				table.insert(lines, { label = "pd2basic_timer_pager", left = math.max(0, left), color = COLORS.pager })
			end
		end
	end
	for key in pairs(T.pagers) do
		if not seen[key] then
			T.pagers[key] = nil
		end
	end
end

local function collect_cameras(lines)
	for _, unit in ipairs(SecurityCamera and SecurityCamera.cameras or {}) do
		local left = alive(unit) and PD2Basic.ESP and PD2Basic.ESP.camera_blind_time(unit)
		if left then
			table.insert(lines, { label = "pd2basic_timer_camera", left = left, color = COLORS.camera })
		end
	end
end

local function collect_ecm(lines, now)
	for ecm in pairs(T.ecms) do
		local unit = ecm._unit
		if alive(unit) then
			if ecm._jammer_active and (ecm._battery_life or 0) > 0 then
				table.insert(lines, { label = "pd2basic_timer_ecm", left = ecm._battery_life, color = COLORS.ecm })
			end
			if ecm._feedback_active and ecm._feedback_expire_t then
				table.insert(lines, { label = "pd2basic_timer_ecm_feedback", left = math.max(0, ecm._feedback_expire_t - now), color = COLORS.ecm })
			end
		end
	end
	for _, data in pairs(managers.groupai:state():all_char_criminals() or {}) do
		local inventory = alive(data.unit) and data.unit:inventory()
		local jammer = inventory and inventory._jammer_data
		if jammer and jammer.t then
			local label = jammer.effect == "feedback" and "pd2basic_timer_pocket_feedback" or "pd2basic_timer_pocket_ecm"
			table.insert(lines, { label = label, left = math.max(0, jammer.t - now), color = COLORS.ecm })
		end
	end
end

local function format_left(left)
	if left >= ENDLESS then
		return PD2Basic.text("pd2basic_timer_endless")
	end
	if left < 10 then
		return string.format(PD2Basic.text("pd2basic_timer_seconds"), string.format("%.1f", left))
	end
	return string.format(PD2Basic.text("pd2basic_timer_seconds"), tostring(math.ceil(left)))
end

local function panel()
	if T.panel and alive(T.panel) then
		return T.panel
	end
	T.ws = managers.gui_data:create_fullscreen_workspace()
	T.panel = T.ws:panel():panel({ layer = 100 })
	T.labels = {}
	return T.panel
end

local function render(lines)
	local root = panel()
	local font = tweak_data.menu.pd2_medium_font
	local size = 20
	local y0 = root:h() * 0.3
	for i = 1, MAX_LINES do
		local line = lines[i]
		local label = T.labels[i]
		if line and not label then
			label = {
				shadow = root:text({ font = font, font_size = size, color = Color(0.8, 0, 0, 0), x = 22, y = y0 + (i - 1) * (size + 4) + 2, w = 400, h = size + 4 }),
				text = root:text({ font = font, font_size = size, x = 20, y = y0 + (i - 1) * (size + 4), w = 400, h = size + 4, layer = 1 }),
			}
			T.labels[i] = label
		end
		if label then
			local value = line and (PD2Basic.text(line.label) .. "  " .. format_left(line.left)) or ""
			label.text:set_text(value)
			label.shadow:set_text(value)
			if line then
				label.text:set_color(line.color)
			end
		end
	end
end

function T.update(t)
	if t < T.next_t then
		return
	end
	T.next_t = t + INTERVAL
	local lines = {}
	if Utils:IsInGameState() and managers.groupai and managers.groupai:state() and managers.enemy and managers.interaction then
		local now = TimerManager:game():time()
		if PD2Basic.is_enabled("timer_camera_loops") then
			collect_cameras(lines)
		end
		if PD2Basic.is_enabled("timer_pagers") then
			collect_pagers(lines, now)
		end
		if PD2Basic.is_enabled("timer_ecm") then
			collect_ecm(lines, now)
		end
	end
	if #lines == 0 and not T.panel then
		return
	end
	table.sort(lines, function(a, b)
		return a.left < b.left
	end)
	render(lines)
end

if not T.hooked then
	T.hooked = true
	Hooks:Add("GameSetupUpdate", "PD2Basic_HudTimers", function(t)
		PD2Basic.safe_call("hud timers", T.update, t)
	end)
end
