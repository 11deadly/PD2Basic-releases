if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

PD2Basic.ESP = PD2Basic.ESP or { units = {}, next_t = 0 }
local ESP = PD2Basic.ESP
local ESP_INTERVAL = 0.2
local LOOP_BLINK_TIME = 5

ESP.colors = {
	cops = Vector3(0.2, 1, 0.3),
	guards = Vector3(1, 0.55, 0),
	civilians = Vector3(1, 1, 1),
	cameras = Vector3(0.2, 0.6, 1),
	camera_loop = Vector3(0.1, 1, 1),
	loot = Vector3(1, 0.85, 0),
	key_holders = Vector3(1, 0.2, 0.9),
}

local LOOT_PATTERNS = {
	"money", "gold", "jewel", "diamond", "coke", "cocaine", "pku", "loot", "cash", "painting",
	"artifact", "weapon_case", "meth", "goat", "pearl", "bond", "ring", "necklace", "watch",
	"wine", "samurai", "chas_", "ammo_crate", "toast", "bag",
}

local function category_enabled(category)
	return PD2Basic.is_enabled("esp_enabled") and PD2Basic.settings["esp_" .. category]
end

if RequiredScript == "lib/units/contourext" then
	for _, category in ipairs({ "cops", "guards", "civilians", "key_holders" }) do
		ContourExt._types["pd2basic_esp_" .. category] = {
			material_swap_required = true,
			priority = 20,
			color = ESP.colors[category],
		}
	end
	for _, category in ipairs({ "cameras", "camera_loop" }) do
		ContourExt._types["pd2basic_esp_" .. category] = {
			priority = 20,
			color = ESP.colors[category],
		}
	end
end

if RequiredScript == "lib/units/interactions/interactionext" then
	local ids_contour_color = Idstring("contour_color")
	local ids_contour_opacity = Idstring("contour_opacity")

	local orig_set_contour = BaseInteractionExt.set_contour
	function BaseInteractionExt:set_contour(color, opacity, ...)
		if self._pd2basic_esp_color then
			for _, m in ipairs(self._materials or {}) do
				m:set_variable(ids_contour_color, self._pd2basic_esp_color)
				m:set_variable(ids_contour_opacity, 1)
			end
			return
		end
		return orig_set_contour(self, color, opacity, ...)
	end

	function ESP.set_interaction_color(ext, color)
		if ext._pd2basic_esp_color == color then
			return
		end
		ext._pd2basic_esp_color = color
		if color then
			ext:set_contour("standard_color")
		else
			orig_set_contour(ext, ext._is_selected and "selected_color" or "standard_color")
		end
	end
end

local function has_pager(unit)
	local data = unit:unit_data()
	return data and data.has_alarm_pager and true or false
end

local function is_loot(unit, ext)
	if unit:carry_data() then
		return true
	end
	local name = tostring(ext.tweak_data or "")
	for _, pattern in ipairs(LOOT_PATTERNS) do
		if name:find(pattern, 1, true) then
			return true
		end
	end
	return false
end

local function is_tied(unit)
	local anim = unit:anim_data()
	if anim and anim.tied then
		return true
	end
	local brain = unit:brain()
	if not brain then
		return false
	end
	return (brain.is_tied and brain:is_tied()) or (brain.is_hostage and brain:is_hostage()) or false
end

local function carries_item(unit)
	local damage = unit:character_damage()
	local pickup = damage and damage.pickup and damage:pickup()
	return type(pickup) == "string" and not pickup:find("ammo", 1, true)
end

local function camera_off(unit)
	local base = unit:base()
	if not base then
		return true
	end
	if base.destroyed and base:destroyed() then
		return true
	end
	return base._pd2basic_detection == false
end

function ESP.camera_blind_time(unit)
	local base = unit:base()
	if not base then
		return nil
	end
	local now = Application:time()
	if base._tape_loop_end_t then
		local restart = managers.groupai:state():whisper_mode() and 5 or 0
		return math.max(0, base._tape_loop_end_t - now) + restart
	end
	if base._tape_loop_restarting_t then
		return math.max(0, base._tape_loop_restarting_t - now)
	end
	return nil
end

local function camera_category(unit, t)
	local blind = ESP.camera_blind_time(unit)
	if not blind then
		return "cameras"
	end
	if blind <= LOOP_BLINK_TIME and math.floor(t * 4) % 2 == 0 then
		return nil
	end
	return "camera_loop"
end

local function collect_targets(t)
	local targets = {}

	local function add_contour(unit, category)
		if alive(unit) and unit:contour() and category_enabled(category) then
			targets[unit:key()] = { unit = unit, kind = "contour", value = "pd2basic_esp_" .. category }
		end
	end

	local function add_npc(unit, category)
		if not alive(unit) then
			return
		end
		if category_enabled("key_holders") and carries_item(unit) then
			add_contour(unit, "key_holders")
		elseif not is_tied(unit) then
			add_contour(unit, category)
		end
	end

	for _, data in pairs(managers.enemy:all_enemies()) do
		if alive(data.unit) then
			add_npc(data.unit, has_pager(data.unit) and "guards" or "cops")
		end
	end
	for _, data in pairs(managers.enemy:all_civilians()) do
		add_npc(data.unit, "civilians")
	end
	for _, unit in ipairs(SecurityCamera and SecurityCamera.cameras or {}) do
		if alive(unit) and not camera_off(unit) then
			local category = camera_category(unit, t)
			if category and category_enabled("cameras") then
				targets[unit:key()] = { unit = unit, kind = "contour", value = "pd2basic_esp_" .. category }
			end
		end
	end

	for _, unit in ipairs(managers.interaction._interactive_units or {}) do
		local ext = alive(unit) and unit:interaction()

		if ext and ext._tweak_data and not targets[unit:key()] and not ext._tweak_data.contour_preset and not ext._tweak_data.no_contour then
			if category_enabled("loot") and is_loot(unit, ext) then
				targets[unit:key()] = { unit = unit, kind = "interaction", value = ESP.colors.loot }
			end
		end
	end

	return targets
end

local function remove_entry(entry)
	if not alive(entry.unit) then
		return
	end
	if entry.kind == "contour" then
		entry.unit:contour():remove(entry.value)
	elseif entry.unit:interaction() and ESP.set_interaction_color then
		ESP.set_interaction_color(entry.unit:interaction(), nil)
	end
end

local function apply_entry(entry)
	if entry.kind == "contour" then
		entry.unit:contour():add(entry.value, false)
	elseif ESP.set_interaction_color then
		ESP.set_interaction_color(entry.unit:interaction(), entry.value)
	end
end

function ESP.update(t)
	if t < ESP.next_t then
		return
	end
	ESP.next_t = t + ESP_INTERVAL
	if not managers.enemy or not managers.interaction or not Utils:IsInGameState() then
		return
	end

	local targets = PD2Basic.is_enabled("esp_enabled") and collect_targets(t) or {}

	for key, entry in pairs(ESP.units) do
		local target = targets[key]
		if not target or target.value ~= entry.value or not alive(entry.unit) then
			remove_entry(entry)
			ESP.units[key] = nil
		end
	end

	for key, target in pairs(targets) do
		if not ESP.units[key] then
			apply_entry(target)
			ESP.units[key] = target
		end
	end
end

if not ESP.hooked then
	ESP.hooked = true
	Hooks:Add("GameSetupUpdate", "PD2Basic_ESPUpdate", function(t, dt)
		PD2Basic.safe_call("esp update", ESP.update, t)
	end)
end
