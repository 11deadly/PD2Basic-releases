if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local function blocking(state)
	return Network:is_server() and PD2Basic.is_enabled("no_alarm") and state:whisper_mode()
end

local function block(class, method)
	local orig = class[method]
	class[method] = function(self, reason, ...)
		if blocking(self) then
			self._pd2basic_blocked = self._pd2basic_blocked or {}
			local tag = method .. ":" .. tostring(reason)
			if not self._pd2basic_blocked[tag] then
				self._pd2basic_blocked[tag] = true
				PD2Basic.log("alarm blocked: " .. tag)
			end
			return
		end
		return orig(self, reason, ...)
	end
end

if RequiredScript == "lib/managers/group_ai_states/groupaistatebesiege" then
	block(GroupAIStateBesiege, "on_enemy_weapons_hot")
	return
end

block(GroupAIStateBase, "on_police_called")
block(GroupAIStateBase, "on_enemy_weapons_hot")
block(GroupAIStateBase, "on_police_weapons_hot")

local orig_set_whisper_mode = GroupAIStateBase.set_whisper_mode
function GroupAIStateBase:set_whisper_mode(enabled, ...)
	if not enabled and blocking(self) then
		PD2Basic.log("alarm blocked: set_whisper_mode(false)")
		return
	end
	return orig_set_whisper_mode(self, enabled, ...)
end
