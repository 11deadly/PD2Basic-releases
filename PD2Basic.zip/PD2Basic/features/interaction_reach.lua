if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

if RequiredScript == "lib/units/interactions/interactionext" then
	local orig_distance = BaseInteractionExt.interact_distance
	function BaseInteractionExt:interact_distance(...)
		return orig_distance(self, ...) * PD2Basic.multiplier("interact_distance_mode")
	end
end

if RequiredScript == "lib/managers/objectinteractionmanager" then
	local orig_raycheck = ObjectInteractionManager._raycheck_ok
	function ObjectInteractionManager:_raycheck_ok(...)
		if PD2Basic.is_enabled("interact_through_walls") then
			return true
		end
		return orig_raycheck(self, ...)
	end
end
