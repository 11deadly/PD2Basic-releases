if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local ENDLESS_LOOP = 100000

local function loops()
	return PD2Basic.is_enabled("infinite_camera_loops")
end

local function endless()
	return PD2Basic.is_enabled("endless_camera_loops")
end

if RequiredScript == "lib/units/props/securitycamera" then
	local orig_update = SecurityCamera.update
	function SecurityCamera:update(unit, t, dt, ...)
		if Network:is_server() and PD2Basic.is_enabled("cameras_no_detection") then
			local handled = PD2Basic.safe_call("camera no detection", function()
				self:_update_tape_loop_restarting(unit, t, dt)
				self:_destroy_all_detected_attention_object_data()
				self:_stop_all_sounds()
				return true
			end)
			if handled then
				return
			end
		end
		return orig_update(self, unit, t, dt, ...)
	end

	local orig_start = SecurityCamera.start_tape_loop
	function SecurityCamera:start_tape_loop(...)
		if loops() then
			SecurityCamera.active_tape_loop_unit = nil
		end
		return orig_start(self, ...)
	end

	local orig_request = SecurityCamera._request_start_tape_loop_by_upgrade_level
	function SecurityCamera:_request_start_tape_loop_by_upgrade_level(...)
		if loops() then
			SecurityCamera.active_tape_loop_unit = nil
		end
		return orig_request(self, ...)
	end

	local orig_detection = SecurityCamera.set_detection_enabled
	function SecurityCamera:set_detection_enabled(state, ...)
		if not self._destroyed then
			self._pd2basic_detection = state and true or false
		end
		return orig_detection(self, state, ...)
	end

	local orig_loop = SecurityCamera._start_tape_loop
	function SecurityCamera:_start_tape_loop(tape_loop_t, ...)
		if endless() then
			tape_loop_t = ENDLESS_LOOP
		end
		local result = orig_loop(self, tape_loop_t, ...)
		if loops() then
			SecurityCamera.active_tape_loop_unit = nil
		end
		return result
	end
end

if RequiredScript == "lib/units/interactions/interactionext" then
	local orig_upgrade = SecurityCameraInteractionExt._has_required_upgrade
	function SecurityCameraInteractionExt:_has_required_upgrade(...)
		if loops() then
			return true
		end
		return orig_upgrade(self, ...)
	end

	local orig_blocked = SecurityCameraInteractionExt._interact_blocked
	function SecurityCameraInteractionExt:_interact_blocked(...)
		if loops() then
			return false
		end
		return orig_blocked(self, ...)
	end

	local orig_interupt = SecurityCameraInteractionExt.check_interupt
	function SecurityCameraInteractionExt:check_interupt(...)
		if loops() then
			return SecurityCameraInteractionExt.super.check_interupt(self, ...)
		end
		return orig_interupt(self, ...)
	end
end
