PD2Basic.sources.presets = function()
	local list = {}
	for name, preset in pairs(PD2Basic.presets) do
		local enabled = {}
		for key, value in pairs(preset) do
			if not PD2Basic.PERSISTENT[key] and value ~= PD2Basic.defaults[key] then
				table.insert(enabled, PD2Basic.text("pd2basic_" .. key .. "_title"))
			end
		end
		table.sort(enabled)
		local summary = #enabled > 0 and table.concat(enabled, ", ") or PD2Basic.text("pd2basic_preset_empty")
		table.insert(list, { id = name, label = name .. ": " .. summary })
	end
	table.sort(list, function(a, b)
		return a.id:lower() < b.id:lower()
	end)
	return list
end

PD2Basic.register_action("save_preset", function()
	local name = (PD2Basic.inputs.preset_name or ""):gsub("^%s+", ""):gsub("%s+$", "")
	if name == "" then
		local n = 1
		while PD2Basic.presets["Preset " .. n] do
			n = n + 1
		end
		name = "Preset " .. n
	end
	local preset = {}
	for key, _ in pairs(PD2Basic.defaults) do
		if not PD2Basic.PERSISTENT[key] then
			preset[key] = PD2Basic.settings[key]
		end
	end
	PD2Basic.presets[name] = preset
	PD2Basic.save_settings()
	PD2Basic.inputs.preset_list = name
	PD2Basic.Overlay.refresh_page()
	PD2Basic.say("preset_saved", name)
end)

local function selected_preset()
	local name = PD2Basic.inputs.preset_list
	if not name or not PD2Basic.presets[name] then
		PD2Basic.say("select_preset")
		return nil
	end
	return name
end

PD2Basic.register_action("load_preset", function()
	local name = selected_preset()
	if not name then
		return
	end
	for key, value in pairs(PD2Basic.presets[name]) do
		if not PD2Basic.PERSISTENT[key] and PD2Basic.defaults[key] ~= nil then
			PD2Basic.settings[key] = value
		end
	end
	PD2Basic.save_settings()
	PD2Basic.Overlay.refresh_page()
	PD2Basic.say("preset_loaded", name)
end)

PD2Basic.register_action("delete_preset", function()
	local name = selected_preset()
	if not name then
		return
	end
	PD2Basic.presets[name] = nil
	PD2Basic.inputs.preset_list = nil
	PD2Basic.save_settings()
	PD2Basic.Overlay.refresh_page()
	PD2Basic.say("preset_deleted", name)
end)

function PD2Basic.load_preset_slot(slot)
	local preset = PD2Basic.sources.presets()[slot]
	if not preset then
		PD2Basic.say("preset_slot_empty", slot)
		return
	end
	PD2Basic.inputs.preset_list = preset.id
	PD2Basic.actions.load_preset()
end
