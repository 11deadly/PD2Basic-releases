if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local MODE_IMMORTAL = 2
local MODE_UNTOUCHABLE = 3
local MODE_BUDDHA = 4
local BUDDHA_MIN_HEALTH = 0.1

local function god_mode()
	if not PD2Basic.is_enabled("god_mode") then
		return 1
	end
	return PD2Basic.settings.god_mode
end

if RequiredScript == "lib/units/beings/player/playerdamage" then
	local orig_change_health = PlayerDamage.change_health
	function PlayerDamage:change_health(change, ...)
		local mode = god_mode()
		if change < 0 and mode == MODE_IMMORTAL then
			return
		end
		if change < 0 and mode == MODE_BUDDHA then
			change = math.max(change, BUDDHA_MIN_HEALTH - self:get_real_health())
			if change >= 0 then
				return
			end
		end
		return orig_change_health(self, change, ...)
	end

	local orig_set_health = PlayerDamage.set_health
	function PlayerDamage:set_health(health, ...)
		local mode = god_mode()
		if mode == MODE_IMMORTAL and health < self:get_real_health() then
			return
		end
		if mode == MODE_BUDDHA then
			health = math.max(health, BUDDHA_MIN_HEALTH)
		end
		return orig_set_health(self, health, ...)
	end

	local orig_can_take_dmg = PlayerDamage._chk_can_take_dmg
	function PlayerDamage:_chk_can_take_dmg(...)
		if god_mode() == MODE_UNTOUCHABLE then
			return false
		end
		return orig_can_take_dmg(self, ...)
	end

	local orig_update = PlayerDamage.update
	function PlayerDamage:update(unit, t, dt, ...)
		local untouchable = god_mode() == MODE_UNTOUCHABLE
		if untouchable then
			self._invulnerable = true
			self._pd2basic_invulnerable = true
		elseif self._pd2basic_invulnerable then
			self._invulnerable = false
			self._pd2basic_invulnerable = nil
		end

		if PD2Basic.is_enabled("auto_revive") and (self:need_revive() or self:arrested()) then
			PD2Basic.safe_call("auto revive", PD2Basic.revive_player, self)
		end

		return orig_update(self, unit, t, dt, ...)
	end
end

if RequiredScript == "lib/units/beings/player/playermovement" then
	local orig_spooced = PlayerMovement.on_SPOOCed
	function PlayerMovement:on_SPOOCed(...)
		if god_mode() == MODE_UNTOUCHABLE then
			return "countered"
		end
		return orig_spooced(self, ...)
	end

	local orig_cuffed = PlayerMovement.on_cuffed
	function PlayerMovement:on_cuffed(...)
		if god_mode() == MODE_UNTOUCHABLE then
			return
		end
		return orig_cuffed(self, ...)
	end
end
