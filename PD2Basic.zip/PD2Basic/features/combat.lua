if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local DAMAGE_ONE_SHOT = 5

local function is_player_weapon(weapon)
	local setup = weapon._setup
	return setup and setup.user_unit and setup.user_unit == managers.player:player_unit()
end

if RequiredScript == "lib/units/weapons/newraycastweaponbase" then
	local orig_recoil = NewRaycastWeaponBase.recoil_multiplier
	function NewRaycastWeaponBase:recoil_multiplier(...)
		if PD2Basic.is_enabled("no_recoil") and is_player_weapon(self) then
			return 0
		end
		return orig_recoil(self, ...)
	end

	local orig_spread = NewRaycastWeaponBase._get_spread
	function NewRaycastWeaponBase:_get_spread(...)
		if PD2Basic.is_enabled("no_spread") and is_player_weapon(self) then
			return 0, 0
		end
		return orig_spread(self, ...)
	end

	local orig_fire_rate = NewRaycastWeaponBase.fire_rate_multiplier
	function NewRaycastWeaponBase:fire_rate_multiplier(...)
		local value = orig_fire_rate(self, ...)
		if is_player_weapon(self) then
			return (value or 1) * PD2Basic.multiplier("fire_rate_mode")
		end
		return value
	end
end

if RequiredScript == "lib/units/enemies/cop/copdamage" then
	local function boost(damage_ext, attack_data)
		if type(attack_data) ~= "table" or type(attack_data.damage) ~= "number" then
			return
		end
		if not PD2Basic.is_enabled("damage_mode") then
			return
		end
		local player = managers.player:player_unit()
		if not player or attack_data.attacker_unit ~= player then
			return
		end
		if PD2Basic.settings.damage_mode == DAMAGE_ONE_SHOT then
			attack_data.damage = math.max(attack_data.damage, (damage_ext._HEALTH_INIT or 1000) * 10)
		else
			attack_data.damage = attack_data.damage * PD2Basic.multiplier("damage_mode")
		end
	end

	for _, method in ipairs({ "damage_bullet", "damage_melee", "damage_explosion", "damage_fire" }) do
		local orig = CopDamage[method]
		CopDamage[method] = function(self, attack_data, ...)
			PD2Basic.safe_call("damage boost", boost, self, attack_data)
			return orig(self, attack_data, ...)
		end
	end
end

if RequiredScript == "lib/managers/playermanager" then
	local orig_crit = PlayerManager.critical_hit_chance
	function PlayerManager:critical_hit_chance(...)
		if PD2Basic.is_enabled("always_critical") then
			return 1
		end
		return orig_crit(self, ...)
	end
end
