if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

PD2Basic.registry = PD2Basic.registry or {
	timers = setmetatable({}, { __mode = "k" }),
	bags = setmetatable({}, { __mode = "k" }),
}

if RequiredScript == "lib/units/props/timergui" then
	Hooks:PostHook(TimerGui, "init", "PD2Basic_RegisterTimer", function(self)
		PD2Basic.registry.timers[self] = true
	end)

	local orig_set_jammed = TimerGui.set_jammed
	function TimerGui:set_jammed(jammed, ...)
		if jammed and PD2Basic.is_enabled("drills_never_jam") then
			return
		end
		return orig_set_jammed(self, jammed, ...)
	end
end

if RequiredScript == "lib/units/props/carrydata" then
	Hooks:PostHook(CarryData, "init", "PD2Basic_RegisterBag", function(self)
		PD2Basic.registry.bags[self] = true
	end)
end
