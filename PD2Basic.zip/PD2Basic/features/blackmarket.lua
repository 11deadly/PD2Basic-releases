local function global_value_of(data)
	local gv = data.global_value or (data.infamous and "infamous") or "normal"
	return gv
end

local function can_give(data)
	if type(data) ~= "table" or data.inaccessible or data.unatainable or data.is_a_unlockable then
		return false
	end
	local gv = global_value_of(data)
	if gv == "normal" or gv == "infamous" then
		return true
	end
	local gv_data = tweak_data.lootdrop.global_values[gv]
	if not gv_data then
		return false
	end
	return not gv_data.dlc or managers.dlc:is_dlc_unlocked(gv)
end

local function give_category(tweak_category, inventory_category)
	local count = math.max(1, math.min(99, math.floor(PD2Basic.input_number("inventory_amount", 1))))
	local given = 0
	for id, data in pairs(tweak_data.blackmarket[tweak_category] or {}) do
		if can_give(data) and id ~= "plastic" and id ~= "no_color_no_material" and id ~= "nothing" and id ~= "character_locked" then
			for _ = 1, count do
				managers.blackmarket:add_to_inventory(global_value_of(data), inventory_category, id, true)
			end
			given = given + 1
		end
	end
	PD2Basic.say("items_added", given, count)
end

PD2Basic.register_profile_action("add_masks", function()
	give_category("masks", "masks")
end)

PD2Basic.register_profile_action("add_materials", function()
	give_category("materials", "materials")
end)

PD2Basic.register_profile_action("add_patterns", function()
	give_category("textures", "textures")
end)

PD2Basic.register_profile_action("add_colors", function()
	give_category("colors", "colors")
end)

PD2Basic.register_profile_action("add_weapon_mods", function()
	local count = math.max(1, math.min(99, math.floor(PD2Basic.input_number("inventory_amount", 1))))
	local given = 0
	for id, data in pairs(tweak_data.blackmarket.weapon_mods or {}) do
		if can_give(data) and (data.pc or data.pcs) then
			for _ = 1, count do
				managers.blackmarket:add_to_inventory(global_value_of(data), "weapon_mods", id, true)
			end
			given = given + 1
		end
	end
	PD2Basic.say("items_added", given, count)
end)
