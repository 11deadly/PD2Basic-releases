if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local EMPTY = {}

local orig_set_attention = PlayerMovement.set_attention_settings
function PlayerMovement:set_attention_settings(settings_list, ...)
	self._pd2basic_attention = settings_list
	if PD2Basic.is_enabled("invisible") then
		self._pd2basic_invisible = true
		return orig_set_attention(self, EMPTY, ...)
	end
	self._pd2basic_invisible = nil
	return orig_set_attention(self, settings_list, ...)
end

local next_t = 0
Hooks:Add("GameSetupUpdate", "PD2Basic_Invisibility", function(t)
	if t < next_t then
		return
	end
	next_t = t + 0.5
	PD2Basic.safe_call("invisibility", function()
		local player = managers.player and managers.player:player_unit()
		local movement = alive(player) and player:movement()
		if not movement or not movement.attention_handler or not movement:attention_handler() then
			return
		end
		local want = PD2Basic.is_enabled("invisible")
		if want and not movement._pd2basic_invisible then
			movement._pd2basic_invisible = true
			orig_set_attention(movement, EMPTY)
			PD2Basic.log("invisibility on")
		elseif not want and movement._pd2basic_invisible then
			movement._pd2basic_invisible = nil
			if movement._pd2basic_attention then
				orig_set_attention(movement, movement._pd2basic_attention)
			end
			PD2Basic.log("invisibility off")
		end
	end)
end)
