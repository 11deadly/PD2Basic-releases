if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

if RequiredScript == "lib/managers/group_ai_states/groupaistatebase" then
	local orig_get_bluffs = GroupAIStateBase.get_nr_successful_alarm_pager_bluffs
	function GroupAIStateBase:get_nr_successful_alarm_pager_bluffs(...)
		if PD2Basic.is_enabled("infinite_pagers") then
			return 0
		end
		return orig_get_bluffs(self, ...)
	end
end

if RequiredScript == "lib/units/enemies/cop/copbrain" then
	local orig_begin = CopBrain.begin_alarm_pager
	function CopBrain:begin_alarm_pager(...)
		if PD2Basic.is_enabled("no_pagers") then
			return
		end
		return orig_begin(self, ...)
	end

	local ALWAYS = { 1, 1, 1, 1, 1 }

	local orig_pager_interaction = CopBrain.on_alarm_pager_interaction
	function CopBrain:on_alarm_pager_interaction(status, ...)
		if status ~= "complete" or not PD2Basic.is_enabled("pager_bluff_success") then
			return orig_pager_interaction(self, status, ...)
		end
		local pager = tweak_data.player.alarm_pager
		local saved = pager.bluff_success_chance
		local saved_skill = pager.bluff_success_chance_w_skill
		pager.bluff_success_chance = ALWAYS
		pager.bluff_success_chance_w_skill = ALWAYS
		local ok, result = pcall(orig_pager_interaction, self, status, ...)
		pager.bluff_success_chance = saved
		pager.bluff_success_chance_w_skill = saved_skill
		if not ok then
			PD2Basic.log("ERROR in pager bluff: " .. tostring(result))
			return
		end
		return result
	end
end
