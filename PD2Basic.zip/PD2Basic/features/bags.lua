if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

PD2Basic.bag_stack = PD2Basic.bag_stack or {}

function PD2Basic.push_current_bag()
	local data = managers.player:get_my_carry_data()
	if type(data) ~= "table" then
		return
	end
	table.insert(PD2Basic.bag_stack, {
		carry_id = data.carry_id,
		multiplier = data.multiplier,
		dye_initiated = data.dye_initiated,
		has_dye_pack = data.has_dye_pack,
		dye_value_multiplier = data.dye_value_multiplier,
	})
end

local function show_bag_count()
	local count = #PD2Basic.bag_stack + (managers.player:is_carrying() and 1 or 0)
	if count > 1 then
		PD2Basic.say("bags_carried", count)
	end
end

local function drop_whole_stack()
	local player = managers.player:player_unit()
	if not alive(player) or not Network:is_server() then
		PD2Basic.bag_stack = {}
		return
	end
	local peer = managers.network:session():local_peer()
	local pos = player:position() + Vector3(0, 0, 50)
	local rot = player:rotation()
	for _, bag in ipairs(PD2Basic.bag_stack) do
		managers.player:server_drop_carry(bag.carry_id, bag.multiplier or 1, bag.dye_initiated, bag.has_dye_pack, bag.dye_value_multiplier, pos, rot, Vector3(0, 0, 1), 0, nil, peer)
	end
	PD2Basic.log("dropped " .. #PD2Basic.bag_stack .. " stacked bags")
	PD2Basic.bag_stack = {}
end

local function after_bag_removed()
	if #PD2Basic.bag_stack == 0 then
		return
	end
	if managers.player:current_state() ~= "standard" then
		drop_whole_stack()
		return
	end
	local bag = table.remove(PD2Basic.bag_stack)
	managers.player:set_carry(bag.carry_id, bag.multiplier or 1, bag.dye_initiated, bag.has_dye_pack, bag.dye_value_multiplier)
	show_bag_count()
end

if RequiredScript == "lib/units/beings/player/states/playercarry" then
	local function weightless()
		return PD2Basic.is_enabled("bags_no_weight")
	end

	local orig_walk_speed = PlayerCarry._get_max_walk_speed
	function PlayerCarry:_get_max_walk_speed(...)
		if weightless() then
			return PlayerCarry.super._get_max_walk_speed(self, ...)
		end
		return orig_walk_speed(self, ...)
	end

	local orig_headbob = PlayerCarry._get_walk_headbob
	function PlayerCarry:_get_walk_headbob(...)
		if weightless() then
			return PlayerCarry.super._get_walk_headbob(self, ...)
		end
		return orig_headbob(self, ...)
	end

	local orig_run = PlayerCarry._check_action_run
	function PlayerCarry:_check_action_run(...)
		if weightless() then
			return PlayerCarry.super._check_action_run(self, ...)
		end
		return orig_run(self, ...)
	end

	local orig_jump = PlayerCarry._perform_jump
	function PlayerCarry:_perform_jump(jump_vec, ...)
		if weightless() then
			return PlayerCarry.super._perform_jump(self, jump_vec, ...)
		end
		return orig_jump(self, jump_vec, ...)
	end
end

if RequiredScript == "lib/managers/playermanager" then
	local orig_sync_carry_data = PlayerManager.sync_carry_data
	function PlayerManager:sync_carry_data(unit, carry_id, carry_multiplier, dye_initiated, has_dye_pack, dye_value_multiplier, position, dir, throw_level, zipline_unit, peer_id, ...)
		local local_peer = managers.network:session() and managers.network:session():local_peer()
		local carry = tweak_data.carry[carry_id]
		local type_data = carry and tweak_data.carry.types[carry.type]
		if type_data and local_peer and peer_id == local_peer:id() and PD2Basic.is_enabled("bags_no_weight") then
			local saved = type_data.throw_distance_multiplier
			type_data.throw_distance_multiplier = math.max(saved or 1, 1)
			local ok, result = pcall(orig_sync_carry_data, self, unit, carry_id, carry_multiplier, dye_initiated, has_dye_pack, dye_value_multiplier, position, dir, throw_level, zipline_unit, peer_id, ...)
			type_data.throw_distance_multiplier = saved
			if not ok then
				PD2Basic.log("ERROR in weightless throw: " .. tostring(result))
			end
			return result
		end
		return orig_sync_carry_data(self, unit, carry_id, carry_multiplier, dye_initiated, has_dye_pack, dye_value_multiplier, position, dir, throw_level, zipline_unit, peer_id, ...)
	end

	Hooks:PostHook(PlayerManager, "drop_carry", "PD2Basic_BagStackDrop", function()
		PD2Basic.safe_call("bag stack drop", after_bag_removed)
	end)

	Hooks:PostHook(PlayerManager, "bank_carry", "PD2Basic_BagStackBank", function()
		PD2Basic.safe_call("bag stack bank", after_bag_removed)
	end)

	Hooks:PreHook(PlayerManager, "clear_carry", "PD2Basic_BagStackClear", function()
		PD2Basic.safe_call("bag stack clear", drop_whole_stack)
	end)
end

if RequiredScript == "lib/units/interactions/interactionext" then
	local function unlimited()
		return PD2Basic.is_enabled("bags_unlimited")
	end

	local orig_blocked = CarryInteractionExt._interact_blocked
	function CarryInteractionExt:_interact_blocked(player, ...)
		if not unlimited() then
			return orig_blocked(self, player, ...)
		end
		local silent_block = managers.player:carry_blocked_by_cooldown() or self._unit:carry_data():is_attached_to_zipline_unit()
		if silent_block then
			return true, silent_block
		end
		return not managers.player:can_carry(self._unit:carry_data():carry_id())
	end

	local orig_can_select = CarryInteractionExt.can_select
	function CarryInteractionExt:can_select(player, ...)
		if not unlimited() then
			return orig_can_select(self, player, ...)
		end
		if managers.player:carry_blocked_by_cooldown() or self._unit:carry_data():is_attached_to_zipline_unit() then
			return false
		end
		return CarryInteractionExt.super.can_select(self, player, ...)
	end

	local orig_interact = CarryInteractionExt.interact
	function CarryInteractionExt:interact(player, ...)
		local stacked = false
		if unlimited() and managers.player:is_carrying() then
			PD2Basic.safe_call("bag stack push", PD2Basic.push_current_bag)
			stacked = true
		end
		local result = orig_interact(self, player, ...)
		if stacked then
			show_bag_count()
		end
		return result
	end
end
