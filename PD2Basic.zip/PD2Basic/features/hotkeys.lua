PD2Basic.Hotkeys = PD2Basic.Hotkeys or {}
local H = PD2Basic.Hotkeys

H.ACTIONS = {
	{ id = "open_main", context = "any" },
	{ id = "screen_player", context = "game", screen = "player" },
	{ id = "screen_weapons", context = "game", screen = "weapons" },
	{ id = "screen_stealth", context = "game", screen = "stealth" },
	{ id = "screen_world", context = "game", screen = "world" },
	{ id = "screen_spawn", context = "game", screen = "spawn" },
	{ id = "screen_profile", context = "any", screen = "profile" },
	{ id = "screen_config", context = "any", screen = "config" },
	{ id = "hk_heal", context = "game", action = "heal" },
	{ id = "hk_revive", context = "game", action = "revive" },
	{ id = "hk_teleport", context = "game", action = "teleport", risk_id = "teleport_now" },
	{ id = "hk_noclip", context = "game" },
	{ id = "hk_answer_pagers", context = "game", action = "answer_pagers" },
	{ id = "hk_bag_corpses", context = "game", action = "bag_all_corpses" },
	{ id = "preset_1", context = "game", preset = 1 },
	{ id = "preset_2", context = "game", preset = 2 },
	{ id = "preset_3", context = "game", preset = 3 },
	{ id = "preset_4", context = "game", preset = 4 },
	{ id = "preset_5", context = "game", preset = 5 },
}

local CANDIDATES = {
	"f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12",
	"num 0", "num 1", "num 2", "num 3", "num 4", "num 5", "num 6", "num 7", "num 8", "num 9",
	"num +", "num -", "num *", "num /", "num .", "num enter",
	"insert", "delete", "home", "end", "page up", "page down",
	"up", "down", "left", "right",
	"1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
	"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
	"n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
	"tab", "caps lock", "left alt", "right alt", "right ctrl", "right shift",
	"`", "-", "=", "[", "]", ";", "'", ",", ".", "/", "\\",
	"pause", "scroll lock",
}

local valid_keys = nil

local function keys()
	if valid_keys then
		return valid_keys
	end
	valid_keys = {}
	local kb = Input:keyboard()
	for _, name in ipairs(CANDIDATES) do
		local ok = pcall(function()
			kb:pressed(Idstring(name))
		end)
		if ok then
			table.insert(valid_keys, { name = name, ids = Idstring(name) })
		end
	end
	return valid_keys
end

local function pressed(kb, name)
	local ok, result = pcall(kb.pressed, kb, Idstring(name))
	return ok and result
end

function H.key_label(action_id)
	local key = PD2Basic.hotkeys[action_id]
	return key and key:upper() or "-"
end

function H.capture(action_id, on_done)
	H._capture = { id = action_id, on_done = on_done, started = Application:time() }
end

function H.is_capturing()
	return H._capture ~= nil
end

local function finish_capture(key)
	local capture = H._capture
	H._capture = nil
	if key == "esc" then
		PD2Basic.say("hotkey_cancelled")
	elseif key == "backspace" then
		PD2Basic.hotkeys[capture.id] = nil
		PD2Basic.save_settings()
		PD2Basic.say("hotkey_cleared")
	else
		for action, other in pairs(PD2Basic.hotkeys) do
			if other == key then
				PD2Basic.hotkeys[action] = nil
			end
		end
		PD2Basic.hotkeys[capture.id] = key
		PD2Basic.save_settings()
		PD2Basic.say("hotkey_set", key:upper())
	end
	if capture.on_done then
		capture.on_done()
	end
end

local function run(def)
	if def.screen then
		PD2Basic.Overlay.toggle_screen(def.screen)
	elseif def.id == "open_main" then
		PD2Basic.Overlay.toggle()
	elseif def.id == "hk_noclip" then
		local function apply()
			PD2Basic.set_setting("noclip", not PD2Basic.settings.noclip)
			PD2Basic.say(PD2Basic.settings.noclip and "noclip_on" or "noclip_off")
			PD2Basic.Overlay.refresh_page()
		end
		if PD2Basic.settings.noclip then
			apply()
		else
			PD2Basic.Widgets.confirm_risk({ id = "noclip" }, apply)
		end
	elseif def.preset then
		PD2Basic.load_preset_slot(def.preset)
	elseif def.action then
		local action = PD2Basic.actions[def.action]
		if def.risk_id then
			PD2Basic.Widgets.confirm_risk({ id = def.risk_id }, action)
		else
			action()
		end
	end
end

function H.update()
	local kb = Input and Input:keyboard()
	if not kb then
		return
	end

	if H._capture then
		if Application:time() - H._capture.started < 0.15 then
			return
		end
		if pressed(kb, "esc") then
			finish_capture("esc")
			return
		end
		if pressed(kb, "backspace") then
			finish_capture("backspace")
			return
		end
		for _, key in ipairs(keys()) do
			if kb:pressed(key.ids) then
				finish_capture(key.name)
				return
			end
		end
		return
	end

	if managers.hud and managers.hud._chat_focus then
		return
	end
	if PD2Basic.Overlay.is_typing() then
		return
	end

	local context = Utils:IsInGameState() and "game" or "menu"
	for _, def in ipairs(H.ACTIONS) do
		local key = PD2Basic.hotkeys[def.id]
		if key and (def.context == "any" or def.context == context) and pressed(kb, key) then
			PD2Basic.safe_call("hotkey " .. def.id, run, def)
		end
	end
end

Hooks:Add("GameSetupUpdate", "PD2Basic_HotkeysGame", function()
	PD2Basic.safe_call("hotkeys", H.update)
end)

Hooks:Add("MenuUpdate", "PD2Basic_HotkeysMenu", function()
	PD2Basic.safe_call("hotkeys", H.update)
end)
