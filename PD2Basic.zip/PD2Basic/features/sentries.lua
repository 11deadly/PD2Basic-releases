if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local function mine(unit)
	local base = alive(unit) and unit:base()
	return base and base.is_owner and base:is_owner()
end

if RequiredScript == "lib/units/weapons/sentrygunweapon" then
	local orig_fire = SentryGunWeapon.fire
	function SentryGunWeapon:fire(blanks, expend_ammo, ...)
		if expend_ammo and PD2Basic.is_enabled("sentry_infinite_ammo") and mine(self._unit) then
			expend_ammo = false
		end
		return orig_fire(self, blanks, expend_ammo, ...)
	end
end

if RequiredScript == "lib/units/equipment/sentry_gun/sentrygundamage" then
	local orig_apply = SentryGunDamage._apply_damage
	function SentryGunDamage:_apply_damage(...)
		if PD2Basic.is_enabled("sentry_invulnerable") and mine(self._unit) then
			return
		end
		return orig_apply(self, ...)
	end
end
