if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local orig_on_throw_grenade = PlayerManager.on_throw_grenade
function PlayerManager:on_throw_grenade(...)
	if PD2Basic.is_enabled("infinite_throwables") then
		PD2Basic.safe_call("infinite throwables stats", function()
			local peer_id = managers.network:session():local_peer():id()
			managers.statistics:used_projectile(self:get_synced_grenades(peer_id).grenade)
		end)
		return
	end
	return orig_on_throw_grenade(self, ...)
end

local orig_remove_equipment = PlayerManager.remove_equipment
function PlayerManager:remove_equipment(equipment_id, slot, ...)
	if PD2Basic.is_enabled("infinite_deployables") then
		return
	end
	if not self:equipment_data_by_name(equipment_id) or not self:has_deployable_left(equipment_id, slot) then
		return
	end
	return orig_remove_equipment(self, equipment_id, slot, ...)
end

local orig_remove_special = PlayerManager.remove_special
function PlayerManager:remove_special(name, ...)
	if name == "cable_tie" then
		if PD2Basic.is_enabled("infinite_cable_ties") then
			return
		end
	elseif PD2Basic.is_enabled("infinite_mission_items") then
		return
	end
	return orig_remove_special(self, name, ...)
end

local orig_on_used_body_bag = PlayerManager.on_used_body_bag
function PlayerManager:on_used_body_bag(...)
	if PD2Basic.is_enabled("infinite_body_bags") then
		return
	end
	return orig_on_used_body_bag(self, ...)
end
