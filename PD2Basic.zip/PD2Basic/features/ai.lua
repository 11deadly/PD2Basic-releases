if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local function enemy_shooter(weapon)
	local user = weapon._setup and weapon._setup.user_unit
	return alive(user) and user:in_slot(managers.slot:get_mask("enemies"))
end

local function block_shots(class)
	if not class then
		return
	end
	for _, method in ipairs({ "singleshot", "trigger_held" }) do
		local orig = class[method]
		if orig then
			class[method] = function(self, ...)
				if PD2Basic.is_enabled("ai_no_shoot") and enemy_shooter(self) then
					return false
				end
				return orig(self, ...)
			end
		end
	end
end

if RequiredScript == "lib/units/weapons/npcraycastweaponbase" then
	block_shots(NPCRaycastWeaponBase)
end

if RequiredScript == "lib/units/weapons/newnpcraycastweaponbase" then
	block_shots(NewNPCRaycastWeaponBase)
end

PD2Basic.AI = PD2Basic.AI or { frozen = {}, next_t = 0, hooked = false }
local AI = PD2Basic.AI

local function each_npc(func)
	for _, list in ipairs({ managers.enemy:all_enemies(), managers.enemy:all_civilians() }) do
		for key, data in pairs(list) do
			if alive(data.unit) then
				func(key, data.unit)
			end
		end
	end
end

function AI.update(t)
	if t < AI.next_t or not managers.enemy or not Network:is_server() then
		return
	end
	AI.next_t = t + 0.5
	local converted = managers.groupai:state():all_converted_enemies() or {}
	if PD2Basic.is_enabled("freeze_ai") then
		each_npc(function(key, unit)
			local brain = unit:brain()
			if not converted[key] and brain and brain.is_active and brain:is_active() then
				brain:set_active(false)
				AI.frozen[key] = unit
			end
		end)
	elseif next(AI.frozen) then
		for key, unit in pairs(AI.frozen) do
			if alive(unit) and not unit:character_damage():dead() then
				pcall(function()
					unit:brain():set_active(true)
				end)
			end
			AI.frozen[key] = nil
		end
	end
end

if not AI.hooked then
	AI.hooked = true
	Hooks:Add("GameSetupUpdate", "PD2Basic_FreezeAI", function(t)
		PD2Basic.safe_call("freeze ai", AI.update, t)
	end)
end
