PD2Basic.register_action("teleport", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local camera = player:camera()
	local from = camera:position()
	local to = from + camera:forward() * 10000
	local ray = World:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("world_geometry"))
	if not ray then
		PD2Basic.say("teleport_none")
		return
	end

	local pos = ray.position + ray.normal * 40
	if ray.normal.z < 0.5 then
		pos = pos - Vector3(0, 0, 80)
	end
	player:warp_to(player:rotation(), pos)
	PD2Basic.say("teleported", math.floor(ray.distance / 100 + 0.5))
end)
