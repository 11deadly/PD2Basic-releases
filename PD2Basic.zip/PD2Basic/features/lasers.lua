if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local function off()
	return PD2Basic.is_enabled("disable_lasers")
end

for _, method in ipairs({ "_check_state", "_client_check_state", "update_laser_draw" }) do
	local orig = ElementLaserTrigger[method]
	if orig then
		ElementLaserTrigger[method] = function(self, ...)
			if off() then
				return
			end
			return orig(self, ...)
		end
	end
end
