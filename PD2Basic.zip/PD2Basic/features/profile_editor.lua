PD2Basic.profile_confirmed = PD2Basic.profile_confirmed or false

function PD2Basic.register_profile_action(name, func)
	PD2Basic.register_action(name, function(...)
		local args = { ... }
		if not PD2Basic.settings.master_enabled then
			PD2Basic.say("master_off")
			return
		end
		if Utils:IsInGameState() then
			PD2Basic.say("menu_only")
			return
		end

		local function run()
			local ok, err = pcall(func, unpack(args))
			if not ok then
				PD2Basic.say("error", name, tostring(err))
				return
			end
			if managers.savefile then
				managers.savefile:save_progress()
			end
		end

		if PD2Basic.profile_confirmed then
			run()
			return
		end

		PD2Basic.Overlay.close()
		QuickMenu:new(
			PD2Basic.text("pd2basic_backup_title"),
			PD2Basic.text("pd2basic_backup_text"),
			{
				{
					text = PD2Basic.text("pd2basic_backup_yes"),
					callback = function()
						PD2Basic.profile_confirmed = true
						PD2Basic.log("profile changes confirmed by user")
						run()
						PD2Basic.Overlay.open()
					end,
				},
				{ text = PD2Basic.text("pd2basic_backup_no"), is_cancel_button = true, callback = PD2Basic.Overlay.open },
			},
			true
		)
	end)
end

local function amount(id, default)
	return math.max(0, math.floor(PD2Basic.input_number(id, default)))
end

PD2Basic.register_profile_action("add_spending", function()
	local value = amount("money_amount", 0)
	managers.money:_add_to_total(value, { no_offshore = true }, "pd2basic")
	PD2Basic.say("spending_added", value, managers.money:total())
end)

PD2Basic.register_profile_action("add_offshore", function()
	local value = amount("money_amount", 0)
	managers.money:add_to_offshore(value)
	PD2Basic.say("offshore_added", value, managers.money:offshore())
end)

PD2Basic.register_profile_action("add_xp", function()
	local value = amount("xp_amount", 0)
	managers.experience:debug_add_points(value, false)
	PD2Basic.say("xp_added", value, managers.experience:current_level())
end)

PD2Basic.register_profile_action("max_level", function()
	local xp = managers.experience
	local guard = 0
	while xp:current_level() < xp:level_cap() and guard < 200 do
		local need = xp:next_level_data_points() - xp:next_level_data_current_points()
		xp:debug_add_points(math.max(need, 1), false)
		guard = guard + 1
	end
	PD2Basic.say("level_now", xp:current_level())
end)

PD2Basic.register_profile_action("add_skill_points", function()
	local value = amount("points_amount", 0)
	local st = managers.skilltree
	st:_set_points(st:points() + value)
	PD2Basic.say("skill_points_added", value, st:points())
end)

PD2Basic.register_profile_action("add_perk_points", function()
	local value = amount("points_amount", 0)
	local st = managers.skilltree
	local spec = st._global.specializations
	local points = st:digest_value(spec.points, false) + value
	local total = st:digest_value(spec.total_points, false) + value
	spec.points = st:digest_value(points, true)
	spec.total_points = st:digest_value(total, true)
	PD2Basic.say("perk_points_added", value, points)
end)

PD2Basic.register_profile_action("set_infamy", function()
	local max_rank = tweak_data.infamy.ranks or 500
	local rank = math.min(amount("infamy_rank", 0), max_rank)
	local xp = managers.experience
	xp._global.rank = Application:digest_value(rank, true)
	xp:update_progress()
	PD2Basic.say("infamy_set", rank, max_rank)
end)

PD2Basic.register_profile_action("unlock_slots", function()
	local bm = managers.blackmarket
	local mask_slots = tweak_data.gui.MAX_MASK_SLOTS or 0
	local weapon_slots = tweak_data.gui.MAX_WEAPON_SLOTS or 0
	for i = 1, mask_slots do
		bm:_unlock_mask_slot(i)
	end
	for i = 1, weapon_slots do
		bm:_unlock_weapon_slot("primaries", i)
		bm:_unlock_weapon_slot("secondaries", i)
	end
	PD2Basic.say("slots_unlocked", mask_slots, weapon_slots)
end)
