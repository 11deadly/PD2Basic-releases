local function host_player()
	local player = PD2Basic.game_player()
	if not player then
		return nil
	end
	if not Network:is_server() then
		PD2Basic.say("host_only")
		return nil
	end
	return player
end

local function units_of(data_table)
	local list = {}
	for _, data in pairs(data_table or {}) do
		if alive(data.unit) then
			table.insert(list, data.unit)
		end
	end
	return list
end

local function is_converted(unit)
	local converted = managers.groupai:state():all_converted_enemies() or {}
	return converted[unit:key()] ~= nil
end

PD2Basic.register_action("kill_all_enemies", function()
	local player = host_player()
	if not player then
		return
	end
	local killed = 0
	for _, unit in ipairs(units_of(managers.enemy:all_enemies())) do
		if not is_converted(unit) and not unit:character_damage():dead() then
			local ok = pcall(function()
				unit:character_damage():damage_mission({
					damage = 1000000,
					attacker_unit = player,
					variant = "explosion",
					col_ray = { position = unit:position(), ray = Vector3(0, 0, -1) },
				})
			end)
			if ok and unit:character_damage():dead() then
				killed = killed + 1
			end
		end
	end
	PD2Basic.say("enemies_killed", killed)
end)

PD2Basic.register_action("tie_all_civilians", function()
	local player = host_player()
	if not player then
		return
	end
	local units, skipped = {}, {}
	local function skip(reason)
		skipped[reason] = (skipped[reason] or 0) + 1
	end
	for _, unit in ipairs(units_of(managers.enemy:all_civilians())) do
		local brain = unit:brain()
		local tweak = tweak_data.character[unit:base()._tweak_table] or {}
		local damage = unit:character_damage()
		if not brain or damage:dead() then
			skip("dead")
		elseif brain:is_tied() then
			skip("already tied")
		elseif tweak.intimidateable == false or unit:base().unintimidateable then
			skip("cannot be intimidated")
		elseif damage._immortal or damage._invulnerable then
			skip("scripted (escort or VIP)")
		else
			pcall(brain.on_intimidated, brain, 1, player)
			table.insert(units, unit)
		end
	end
	local parts = {}
	for reason, count in pairs(skipped) do
		table.insert(parts, reason .. ": " .. count)
	end
	PD2Basic.log("tie civilians: " .. #units .. " to tie, skipped " .. (#parts > 0 and table.concat(parts, ", ") or "none"))

	DelayedCalls:Add("PD2Basic_TieCivilians1", 0.8, function()
		for _, unit in ipairs(units) do
			local brain = alive(unit) and unit:brain()
			if brain and not brain:is_current_logic("surrender") then
				pcall(brain.set_logic, brain, "surrender")
			end
		end
		DelayedCalls:Add("PD2Basic_TieCivilians2", 0.8, function()
			local tied = 0
			for _, unit in ipairs(units) do
				if alive(unit) and pcall(function()
					unit:brain():on_tied(player, false, false)
				end) and unit:brain():is_tied() then
					tied = tied + 1
				end
			end
			PD2Basic.say("civilians_tied", tied, #units)
		end)
	end)
	PD2Basic.say("civilians_tying", #units)
end)

PD2Basic.register_action("convert_all_enemies", function()
	local player = host_player()
	if not player then
		return
	end
	local state = managers.groupai:state()

	local pm = managers.player
	pm.upgrade_value = function(self, category, upgrade, default)
		if category == "player" and upgrade == "convert_enemies_max_minions" then
			return 1000
		end
		return PlayerManager.upgrade_value(self, category, upgrade, default)
	end
	local converted = 0
	for _, unit in ipairs(units_of(managers.enemy:all_enemies())) do
		if not is_converted(unit) and not unit:character_damage():dead() then
			if pcall(state.convert_hostage_to_criminal, state, unit) and is_converted(unit) then
				converted = converted + 1
			end
		end
	end
	pm.upgrade_value = nil
	PD2Basic.say("enemies_converted", converted)
end)

PD2Basic.register_action("finish_timers", function()
	if not host_player() then
		return
	end
	local finished, unpowered = 0, 0
	for timer, _ in pairs(PD2Basic.registry.timers) do
		if alive(timer._unit) and timer._started and not timer._done then
			if timer._jammed then
				timer:set_jammed(false)
			end
			timer._current_jam_timer = nil
			timer._jamming_intervals = {}
			timer._current_timer = 0.01
			timer._unit:set_extension_update_enabled(Idstring("timer_gui"), true)
			timer._update_enabled = true
			if timer._powered == false then
				unpowered = unpowered + 1
			end
			finished = finished + 1
		end
	end
	if unpowered > 0 then
		PD2Basic.say("timers_finished_unpowered", finished, unpowered)
	else
		PD2Basic.say("timers_finished", finished)
	end
end)

PD2Basic.register_action("answer_pagers", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local pagers = {}
	for _, unit in ipairs(managers.interaction._interactive_units or {}) do
		local ext = alive(unit) and unit:interaction()
		if ext and ext.tweak_data == "corpse_alarm_pager" and ext:active() then
			table.insert(pagers, ext)
		end
	end
	local answered = 0
	for _, ext in ipairs(pagers) do
		if pcall(ext.interact, ext, player) then
			answered = answered + 1
		end
	end
	PD2Basic.say("pagers_answered", answered)
end)

local MAP_ACTIONS = {
	open_all_doors = { "pick_lock", "lockpick", "picklock", "open_door", "breach_door", "pry_open_door", "door_crowbar", "embassy_door", "electric_lock" },
	open_deposit_boxes = { "safety_deposit", "pick_lock_deposit" },
	open_atms = { "atm_interaction", "requires_ecm_jammer_atm" },
	answer_phones = { "pickup_phone", "iphone_answer", "hospital_phone", "phone_call", "bus_wall_phone" },
}

local MAP_SKIP = { "close", "cant_" }

local function matches(name, patterns)
	for _, pattern in ipairs(patterns) do
		if name:find(pattern, 1, true) then
			return true
		end
	end
	return false
end

for action, patterns in pairs(MAP_ACTIONS) do
	PD2Basic.register_action(action, function()
		local player = PD2Basic.game_player()
		if not player then
			return
		end
		local targets = {}
		for _, unit in ipairs(managers.interaction._interactive_units or {}) do
			local ext = alive(unit) and unit:interaction()
			local name = ext and tostring(ext.tweak_data or "")
			if ext and ext:active() and matches(name, patterns) and not matches(name, MAP_SKIP) then
				table.insert(targets, ext)
			end
		end
		local done = 0
		for _, ext in ipairs(targets) do
			if pcall(ext.interact, ext, player) then
				done = done + 1
			end
		end
		PD2Basic.say("map_action_done", PD2Basic.text("pd2basic_" .. action .. "_title"), done)
	end)
end

PD2Basic.register_action("pickup_small_loot", function()
	local player = host_player()
	if not player then
		return
	end
	local units = {}
	for _, unit in ipairs(managers.interaction._interactive_units or {}) do
		local base = alive(unit) and unit:base()
		if base and (base.take_money or (base.take and base.taken)) then
			table.insert(units, unit)
		end
	end
	local taken = 0
	for _, unit in ipairs(units) do
		local ext = alive(unit) and unit:interaction()
		if ext and ext:active() and pcall(ext.interact, ext, player) then
			taken = taken + 1
		end
	end
	PD2Basic.say("small_loot_taken", taken)
end)

PD2Basic.register_action("secure_all_bags", function()
	if not host_player() then
		return
	end
	local peer_id = managers.network:session():local_peer():id()
	local secured = 0
	for carry, _ in pairs(PD2Basic.registry.bags) do
		local unit = carry._unit
		local carry_id = alive(unit) and unit:enabled() and carry:carry_id()
		if carry_id and carry_id ~= "person" and tweak_data.carry[carry_id] and not carry:is_linked_to_unit() and not carry:is_attached_to_zipline_unit() then
			managers.loot:secure(carry_id, carry:multiplier() or 1, false, peer_id)
			unit:set_slot(0)
			secured = secured + 1
		end
	end

	local guard = 0
	while managers.player:is_carrying() and guard < 100 do
		local carry_id = managers.player:current_carry_id()
		if carry_id == "person" then
			break
		end
		managers.player:bank_carry()
		secured = secured + 1
		guard = guard + 1
	end
	PD2Basic.say("bags_secured", secured)
end)

PD2Basic.register_action("bag_all_corpses", function()
	if not host_player() then
		return
	end
	local peer = managers.network:session():local_peer()
	local bagged = 0
	for _, data in pairs(managers.enemy._enemy_data.corpses or {}) do
		local unit = data.unit
		local ext = alive(unit) and unit:interaction()
		if ext and ext._active and ext.tweak_data == "corpse_dispose" then
			local pos = unit:position() + Vector3(0, 0, 40)
			ext:remove_interact()
			ext:set_active(false, true)
			unit:set_slot(0)
			managers.network:session():send_to_peers_synched("remove_corpse_by_id", data.u_id, true, peer:id())
			managers.player:server_drop_carry("person", 1, true, false, 1, pos, Rotation(), Vector3(0, 0, 0), 0, nil, peer)
			bagged = bagged + 1
		end
	end
	PD2Basic.say("corpses_bagged", bagged)
end)

PD2Basic.register_action("win_heist", function()
	if not host_player() then
		return
	end
	PD2Basic.Overlay.close()
	local num_winners = managers.network:session():amount_of_alive_players()
	managers.network:session():send_to_peers("mission_ended", true, num_winners)
	game_state_machine:change_state_by_name("victoryscreen", {
		num_winners = num_winners,
		personal_win = alive(managers.player:player_unit()),
	})
	PD2Basic.log("heist won by trainer")
end)

PD2Basic.register_action("collect_gage_packages", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local gage = managers.gage_assignment
	local units = gage and gage._spawned_units or {}
	local collected = 0

	local copy = {}
	for _, unit in ipairs(units) do
		table.insert(copy, unit)
	end
	for _, unit in ipairs(copy) do
		if alive(unit) and unit:interaction() and unit:interaction():active() then
			unit:interaction():interact(player)
			collected = collected + 1
		end
	end
	PD2Basic.say("gage_collected", collected)
end)
