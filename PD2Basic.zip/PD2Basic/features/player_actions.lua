function PD2Basic.revive_player(damage_ext)
	local max_lives = damage_ext._lives_init + managers.player:upgrade_value("player", "additional_lives", 0)
	damage_ext._revives = Application:digest_value(math.max(max_lives, 1), true)
	damage_ext:revive(true)
end

PD2Basic.register_action("heal", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local damage = player:character_damage()
	if damage:need_revive() or damage:arrested() then
		PD2Basic.revive_player(damage)
	end
	damage:replenish()
	PD2Basic.say("healed")
end)

PD2Basic.register_action("revive", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local damage = player:character_damage()
	if not (damage:need_revive() or damage:arrested()) then
		PD2Basic.say("not_down")
		return
	end
	PD2Basic.revive_player(damage)
	PD2Basic.say("revived")
end)

PD2Basic.register_action("refill_consumables", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local pm = managers.player
	local done = {}

	do
		local peer_id = managers.network:session():local_peer():id()
		local max_grenades = pm:get_max_grenades_by_peer_id(peer_id)
		local missing = max_grenades - pm:get_grenade_amount(peer_id)
		if missing > 0 then
			pm:add_grenade_amount(missing, true)
			table.insert(done, PD2Basic.text("pd2basic_msg_part_throwables"))
		end

		local selections = pm._equipment.selections or {}
		for _, selection in ipairs(selections) do
			pm:add_equipment_amount(selection.equipment, 1)
		end
		if #selections > 0 then
			table.insert(done, PD2Basic.text("pd2basic_msg_part_deployables"))
		end
	end

	pm:add_cable_ties(tweak_data.equipments.specials.cable_tie.max_quantity or 10)
	table.insert(done, PD2Basic.text("pd2basic_msg_part_cable_ties"))

	pm:_set_body_bags_amount(pm:max_body_bags())
	table.insert(done, PD2Basic.text("pd2basic_msg_part_body_bags"))

	PD2Basic.say("refilled", table.concat(done, ", "))
end)
