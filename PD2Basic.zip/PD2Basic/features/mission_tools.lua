local element_cache = nil

PD2Basic.sources.mission_elements = function()
	if element_cache then
		return element_cache
	end
	local list = {}
	if not managers.mission or not managers.mission:scripts() then
		return list
	end
	for script_name, script in pairs(managers.mission:scripts()) do
		for id, element in pairs(script:elements()) do
			local name = element._editor_name or "?"
			table.insert(list, { id = id, label = tostring(id) .. "  " .. tostring(name) .. "  (" .. tostring(script_name) .. ")" })
		end
	end
	table.sort(list, function(a, b)
		return a.id < b.id
	end)
	if #list > 0 then
		element_cache = list
	end
	return list
end

PD2Basic.register_action("run_element", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	if not Network:is_server() then
		PD2Basic.say("host_only")
		return
	end
	local id = PD2Basic.inputs.element_list
	local element = id and managers.mission:get_element_by_id(id)
	if not element then
		PD2Basic.say("select_element")
		return
	end
	if element._values and not element._values.enabled then
		element._values.enabled = true
	end
	element:on_executed(player)
	PD2Basic.say("element_run", tostring(id), tostring(element._editor_name or "?"))
end)
