if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

if RequiredScript == "lib/managers/group_ai_states/groupaistatebase" then
	local orig_hostage_killed = GroupAIStateBase.hostage_killed
	function GroupAIStateBase:hostage_killed(killer_unit, ...)
		if PD2Basic.profile_enabled("no_civilian_penalty") and PD2Basic.is_allowed() then
			local killer = killer_unit
			if alive(killer) and killer:base() and killer:base().thrower_unit then
				killer = killer:base():thrower_unit()
			end
			if alive(killer) and killer == managers.player:player_unit() then
				return
			end
		end
		return orig_hostage_killed(self, killer_unit, ...)
	end

	local orig_ponr = GroupAIStateBase._update_point_of_no_return
	function GroupAIStateBase:_update_point_of_no_return(t, dt, ...)
		if PD2Basic.is_enabled("freeze_ponr") then
			return
		end
		return orig_ponr(self, t, dt, ...)
	end
end

if RequiredScript == "lib/managers/moneymanager" then
	local orig_deduction = MoneyManager.get_civilian_deduction
	function MoneyManager:get_civilian_deduction(...)
		if PD2Basic.profile_enabled("no_civilian_penalty") then
			return 0
		end
		return orig_deduction(self, ...)
	end

	local orig_completed = MoneyManager.on_mission_completed
	function MoneyManager:on_mission_completed(...)
		local mul = PD2Basic.multiplier("money_mode")
		if mul == 1 then
			return orig_completed(self, ...)
		end
		local before = self:total() + self:offshore()
		local result = orig_completed(self, ...)
		local earned = self:total() + self:offshore() - before
		if earned > 0 then
			self:_add_to_total(earned * (mul - 1), nil, "pd2basic")
			PD2Basic.log("heist payout x" .. mul .. ": +" .. math.floor(earned * (mul - 1)))
		end
		return result
	end
end

if RequiredScript == "lib/managers/experiencemanager" then
	local orig_give = ExperienceManager.give_experience
	function ExperienceManager:give_experience(xp, ...)
		local mul = PD2Basic.multiplier("xp_mode")
		if mul ~= 1 and type(xp) == "number" then
			PD2Basic.log("heist xp x" .. mul .. ": " .. xp .. " -> " .. math.floor(xp * mul))
			xp = math.floor(xp * mul)
		end
		return orig_give(self, xp, ...)
	end
end
