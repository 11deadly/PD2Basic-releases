if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local orig_get_timer = BaseInteractionExt._get_timer

function BaseInteractionExt:_get_timer(...)
	local timer = orig_get_timer(self, ...)
	if type(timer) ~= "number" then
		return timer
	end
	if PD2Basic.is_enabled("instant_interaction") then
		return 0
	end
	return timer / PD2Basic.multiplier("interaction_speed_mode")
end
