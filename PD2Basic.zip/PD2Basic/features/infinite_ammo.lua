if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

local MODE_NO_CONSUME = 2
local MODE_NO_RELOAD = 3

local orig_use_ammo = RaycastWeaponBase.use_ammo

local function is_local_player_weapon(weapon)
	return weapon._setup and weapon._setup.user_unit and weapon._setup.user_unit == managers.player:player_unit()
end

function RaycastWeaponBase:use_ammo(base, ammo_usage, ...)
	if PD2Basic.is_enabled("ammo_mode") and is_local_player_weapon(self) then
		local mode = PD2Basic.settings.ammo_mode
		if mode == MODE_NO_RELOAD then
			local ok = PD2Basic.safe_call("no reload", function()
				base:set_ammo_remaining_in_clip(base:get_ammo_max_per_clip())
				if self.set_magazine_empty then
					self:set_magazine_empty(false)
				end
				return true
			end)
			if ok then
				return
			end
		elseif mode == MODE_NO_CONSUME then
			return
		end
	end
	return orig_use_ammo(self, base, ammo_usage, ...)
end
