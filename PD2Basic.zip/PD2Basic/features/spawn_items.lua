local function loc_or(id, fallback)
	if id and managers.localization and managers.localization:exists(id) then
		return managers.localization:text(id)
	end
	return fallback
end

local function sort_by_label(list)
	table.sort(list, function(a, b)
		return a.label:lower() < b.label:lower()
	end)
	return list
end

PD2Basic.sources.spawnables = function()
	local bags, items = {}, {}
	for id, data in pairs(tweak_data.carry) do
		if type(data) == "table" and data.type and tweak_data.carry.types[data.type] then
			table.insert(bags, { id = "bag:" .. id, label = "Bag: " .. loc_or(data.name_id, id) .. "  (" .. id .. ")" })
		end
	end
	for id, data in pairs(tweak_data.equipments.specials) do
		if type(data) == "table" and data.icon and data.text_id then
			table.insert(items, { id = "item:" .. id, label = "Item: " .. loc_or(data.text_id, id) .. "  (" .. id .. ")" })
		end
	end

	local list = sort_by_label(items)
	for _, bag in ipairs(sort_by_label(bags)) do
		table.insert(list, bag)
	end
	return list
end

local function selected()
	local value = PD2Basic.inputs.spawn_list
	if not value then
		PD2Basic.say("select_item")
		return nil
	end
	return value:match("^(%a+):(.+)$")
end

local function give_bag(carry_id)
	local pm = managers.player
	if pm:is_carrying() then
		if PD2Basic.is_enabled("bags_unlimited") and PD2Basic.push_current_bag then
			PD2Basic.push_current_bag()
		else
			pm:drop_carry()
		end
	end
	pm:register_carry(managers.network:session():local_peer(), carry_id)
	pm:set_carry(carry_id, 1, true, false, 1)
	PD2Basic.say("bag_given", carry_id)
end

PD2Basic.register_action("give_selected", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local kind, id = selected()
	if kind == "bag" then
		if not Network:is_server() then
			PD2Basic.say("bags_host_only")
			return
		end
		give_bag(id)
	elseif kind == "item" then
		managers.player:add_special({ name = id })
		PD2Basic.say("item_given", id)
	end
end)

PD2Basic.register_action("spawn_bag", function()
	local player = PD2Basic.game_player()
	if not player then
		return
	end
	local kind, carry_id = selected()
	if not kind then
		return
	end
	if not Network:is_server() then
		PD2Basic.say("host_only")
		return
	end
	if kind ~= "bag" then
		PD2Basic.say("only_bags_spawn")
		return
	end
	local camera = player:camera()
	local forward = camera:forward()
	local pos = camera:position() + forward * 80
	local unit = managers.player:server_drop_carry(carry_id, 1, true, false, 1, pos, camera:rotation(), forward, 0, nil, managers.network:session():local_peer())
	if unit then
		PD2Basic.say("bag_spawned", carry_id)
	else
		PD2Basic.say("bag_spawn_failed", carry_id)
	end
end)
