if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

if RequiredScript == "lib/units/beings/player/states/playerstandard" then
	local orig_charge = PlayerStandard._get_melee_charge_lerp_value
	function PlayerStandard:_get_melee_charge_lerp_value(t, offset, ...)
		if PD2Basic.is_enabled("melee_instant_charge") and self._state_data.melee_start_t then
			return 1
		end
		return orig_charge(self, t, offset, ...)
	end

	local orig_do = PlayerStandard._do_action_melee
	function PlayerStandard:_do_action_melee(t, ...)
		local result = orig_do(self, t, ...)
		if PD2Basic.is_enabled("melee_no_cooldown") then
			self._state_data.melee_repeat_expire_t = t + 0.05
		end
		return result
	end

	local orig_ray = PlayerStandard._calc_melee_hit_ray
	function PlayerStandard:_calc_melee_hit_ray(...)
		local mul = PD2Basic.multiplier("melee_range_mode")
		if mul == 1 then
			return orig_ray(self, ...)
		end
		local melee = tweak_data.blackmarket.melee_weapons[managers.blackmarket:equipped_melee_weapon()]
		local stats = melee and melee.stats
		if not stats then
			return orig_ray(self, ...)
		end
		local saved = stats.range
		stats.range = (saved or 175) * mul
		local ok, result = pcall(orig_ray, self, ...)
		stats.range = saved
		return ok and result or nil
	end
end

if RequiredScript == "lib/units/enemies/cop/copdamage" then
	local orig_melee = CopDamage.damage_melee
	function CopDamage:damage_melee(attack_data, ...)
		local mul = PD2Basic.multiplier("melee_damage_mode")
		if mul ~= 1 and type(attack_data) == "table" and type(attack_data.damage) == "number" and attack_data.attacker_unit == managers.player:player_unit() then
			attack_data.damage = attack_data.damage * mul
		end
		return orig_melee(self, attack_data, ...)
	end
end
