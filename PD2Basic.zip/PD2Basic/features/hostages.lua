if not PD2Basic then
	dofile(ModPath .. "core.lua")
end

if RequiredScript == "lib/units/enemies/cop/logics/coplogicbase" then
	local orig_reason = CopLogicBase._evaluate_reason_to_surrender
	function CopLogicBase._evaluate_reason_to_surrender(data, my_data, aggressor_unit, ...)
		if PD2Basic.is_enabled("instant_domination") and aggressor_unit == managers.player:player_unit() and data.char_tweak.surrender then
			return 0
		end
		return orig_reason(data, my_data, aggressor_unit, ...)
	end
	return
end

if RequiredScript == "lib/managers/group_ai_states/groupaistatebase" then
	local orig_room = GroupAIStateBase.has_room_for_police_hostage
	function GroupAIStateBase:has_room_for_police_hostage(...)
		if PD2Basic.is_enabled("instant_domination") then
			return true
		end
		return orig_room(self, ...)
	end
	return
end

local DOMINATION_SKILLS = { intimidate_enemies = true, intimidate_specials = true }
local orig_has_upgrade = PlayerManager.has_category_upgrade
function PlayerManager:has_category_upgrade(category, upgrade, ...)
	if category == "player" and DOMINATION_SKILLS[upgrade] and PD2Basic.is_enabled("instant_domination") then
		return true
	end
	return orig_has_upgrade(self, category, upgrade, ...)
end

local orig_upgrade_value = PlayerManager.upgrade_value
function PlayerManager:upgrade_value(category, upgrade, default, ...)
	if upgrade == "convert_enemies_max_minions" and category == "player" and PD2Basic.is_enabled("unlimited_jokers") then
		return 100
	end
	return orig_upgrade_value(self, category, upgrade, default, ...)
end
